# install sklearn sudo apt-get install python-sklearn
             
import numpy as np   
import networkx as nx        

import matplotlib.pyplot as plt
import string
from networkx.drawing.nx_agraph import graphviz_layout
   
dt = [("Similiarity", float)] 
A = np.array([(0, 0.3, 0.4, 0.7),
               (0.3, 0, 0.9, 0.2),
               (0.4, 0.9, 0, 0.1),
               (0.7, 0.2, 0.1, 0)
               ])
A = A.view(dt)
G = nx.from_numpy_matrix(A)
nx.draw(G)
plt.show()
 
def getData(path):
    f = open(path)
    matrix = []
    for line in f.readlines():
        data = line.split("\t");
        l = []
        for number in data:
            if number != '\n':
                l.append(float(number))
        matrix.append((l))
    print matrix
     
    print len(matrix), len(matrix[0])
    return matrix

similarities = getData("/home/zcp/workspace/match_result.txt")

A = np.array(similarities, dtype=float)
print "A",A
#A = A.view(dt)

#new_labels = {}
def fillG(matrix,G):
    global new_labels
    row = len(matrix)
    column = len(matrix[0])

    if row < 0 or column < 0:
        print "error on matrix demension"
    
    for i in range(0, row):
        for j in range(0, column):
            if matrix[i][j] >= 40:
                G.add_node(i+1, name=i+1)
                G.add_node(j+1, name=j+1)
                G.add_edge(i+1,j+1,weight=int(matrix[i][j])) 
                #new_labels[(i,j)] = int(matrix[i][j]) 
                
    return G 

def drawGraph(matrix):
    G = nx.Graph()
    fillG(matrix,G)
    #pos=nx.spring_layout(G)
 
    pos = graphviz_layout(G,prog='neato')
    #pos = nx.spring_layout(G,scale=2)
    #pos = graphviz_layout(G)
    nx.draw_networkx(G, pos=pos, with_labels=True, label ="similarity")
    new_labels = dict(map(lambda x:((x[0],x[1]), str(x[2]['weight'] if x[2]['weight']>=40 else "") ), G.edges(data = True)))
    #print new_labels
    nx.draw_networkx_edge_labels(G, pos, edge_labels=new_labels )
    nx.draw_networkx_edges(G,pos,width=4, edge_color='black', arrows=False,label="Similarities")
    labels=["Student NO","Similarity"]
    plt.legend(labels)
    plt.show()
    
drawGraph(similarities)    
#edge_labels=dict([((u,v,),d['weight'])
#         for u,v,d in G.edges(data=True)])
#nx.draw_networkx_edge_labels(G,pos,edge_labels=edge_labels)


#nx.draw(G, with_labels = True)


#edge_labels=nx.draw_networkx_edge_labels(G,pos=nx)



#pos=nx.spring_layout(G)
#nx.draw_networkx_nodes(G, pos)
#nx.draw_networkx_edges(G, pos)
#nx.draw_networkx_labels(G, pos, labels, font_size=16)

#nx.draw(G)
#plt.show()

#G = nx.from_numpy_matrix(similarities)
#nx.draw(G)
 