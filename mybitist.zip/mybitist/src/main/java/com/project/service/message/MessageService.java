package com.project.service.message;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.message.Message;
import com.project.entity.organization.Department;
import com.project.entity.permission.Operator;
import org.springframework.stereotype.Service;

@Service
public interface MessageService {
    /**
     *
     * @param
     */
    public Message sendRegistCodeMessage(String toEmial) throws Exception;

    //校验验证码是否过期
    public boolean isTimeOnForVeriedCode(String email,String authCode) ;

    /*获取所有的消息，包括成员变动与作业发布信息。*/
    public JSONObject findAllTypeMessage(Operator operator,JSONObject params);

    public JSONObject countScoresSubmit(JSONObject params);

    }
