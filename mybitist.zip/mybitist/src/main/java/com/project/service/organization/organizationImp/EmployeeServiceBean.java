package com.project.service.organization.organizationImp;

import com.alibaba.fastjson.JSONObject;
import com.eaio.uuid.UUID;
import com.project.dao.organization.EmployeeDao;
import com.project.dao.permission.OperatorDao;
import com.project.dao.permission.RoleDao;
import com.project.entity.OperatorConfig;
import com.project.entity.organization.Department;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import com.project.entity.permission.OperatorAndRole;
import com.project.entity.permission.Role;
import com.project.service.AppService;
import com.project.service.message.MessageService;
import com.project.service.organization.EmployeeService;
import com.project.service.permission.OperatorService;
import com.project.service.permission.RoleService;
import com.project.util.Aes;
import com.project.util.AuthenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public class EmployeeServiceBean extends AppService implements EmployeeService {

    @Autowired
    RoleService roleService;

    @Autowired
    RoleDao roleDao;

    @Autowired
    EmployeeDao employeeDao;

    @Autowired
    OperatorService operatorService;

    @Autowired
    MessageService messageService;

    @Autowired
    OperatorDao operatorDao;

    AuthenUtil authenUtil = new AuthenUtil();

    //人员注册
    public JSONObject registPerson(JSONObject jsonObject) {
        JSONObject returnObj = new JSONObject();

        //从对象中获取数据
        String email = String.valueOf(jsonObject.get("email"));
        String authCOde = String.valueOf(jsonObject.get("authCOde"));
        String userName = String.valueOf(jsonObject.get("userName"));

        //验证码是否过期
        boolean isTimeOver = messageService.isTimeOnForVeriedCode(email,authCOde);
        if(isTimeOver == true){//如果已经过期了，那么就要返回失败消息
            returnObj.put("status","失败");
            returnObj.put("message","验证码错误，请重新发送");
            returnObj.put("code",2000);
            return returnObj;
        }

        //判断是否被注册
        Operator operator = operatorService.findOperatorByUserName(userName);
        if(operator != null){
            returnObj.put("status","失败");
            returnObj.put("message","用户名已被注册");
            returnObj.put("code",2000);
            return returnObj;
        }

        Employee employee = employeeDao.findAnEmployeeByEmail(email);
        if(employee != null){
            returnObj.put("status","失败");
            returnObj.put("message","邮箱已被绑定");
            returnObj.put("code",2000);
            return returnObj;
        }


        /*---------------开始存储操作----------------------------------------*/
        //保存职员
        Employee savedEmp = new Employee();
        savedEmp = this.saveEmployee(jsonObject);

        if (savedEmp == null) {
            returnObj.put("status", "失败");
            returnObj.put("code", 501);
            returnObj.put("message", "操作员保存失败");
            return returnObj;
        }

        //存储操作员
        Operator savedOperator = new Operator();
        savedOperator = this.saveOperator(jsonObject, savedEmp);

        if (savedOperator == null) {
            returnObj.put("status", "失败");
            returnObj.put("code", 501);
            returnObj.put("message", "操作员保存失败");
            return returnObj;
        }

        //分配角色,t代表老师，s代表学生
        boolean isSuccess = true;
        isSuccess = saveRoleAndOperator(jsonObject, savedOperator);

        if (isSuccess == false) {//如果不成功，那么就直接返回结果并且开始回滚
            returnObj.put("status", "失败");
            returnObj.put("code", 501);
            returnObj.put("message", "分配角色失败");
        }

        returnObj.put("status", "成功");
        returnObj.put("code", 200);
        returnObj.put("message", "注册成功");

        return returnObj;
    }


    public Employee saveEmployee(JSONObject jsonObject) {
        try {
            String email = String.valueOf(jsonObject.get("email"));
            //新建人员
            UUID uuidO = new UUID();
            String uuidS = uuidO.toString();
            Employee employee = new Employee();
            employee.setEmail(email);
            employee.setCreateDate(new Date());
            employee.setUuid(uuidS);

            employee = employeeDao.saveEmployee(employee);
            return employee;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Operator saveOperator(JSONObject jsonObject, Employee employee) {
        try {

            //获取数据
            String userName = String.valueOf(jsonObject.get("userName"));
            String password = String.valueOf(jsonObject.get("password"));

            password = Aes.aesEncrypt(password);

            //新建操作员
            //appid生成
            UUID uuidObj = new UUID();
            String uuidStr = uuidObj.toString();

            //建立操作员
            Operator operator = new Operator();
            operator.setAppId(uuidStr);
            operator.setEmployee(employee);
            operator.setPassword(password);
            operator.setUsername(userName);
            operator.setCreateDate(new Date());
            operator.setEmpId(employee.getId());

            operator = operatorService.saveOperator(operator);
            return operator;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Boolean saveRoleAndOperator(JSONObject jsonObject, Operator operator) {
        try {
            //从对象中获取数据
            String role = String.valueOf(jsonObject.get("role"));

            //分配角色,t代表老师，s代表学生
            boolean isSuccess = true;
            if ("t".equals(role)) {
                Role findRole = roleService.getRoleByRoleCode("js");
                OperatorAndRole newOperatorAndRole = new OperatorAndRole();
                newOperatorAndRole.setOperatorId(operator.getId());
                newOperatorAndRole.setRoleId(findRole.getId());

                isSuccess = roleService.distributeRoleForOperator(newOperatorAndRole);
            } else if ("s".equals(role)) {
                Role findRole = roleService.getRoleByRoleCode("xy");
                OperatorAndRole newOperatorAndRole = new OperatorAndRole();
                newOperatorAndRole.setOperatorId(operator.getId());
                newOperatorAndRole.setRoleId(findRole.getId());
                newOperatorAndRole.setCreateDate(new Date());

                isSuccess = roleService.distributeRoleForOperator(newOperatorAndRole);
            }
            return isSuccess;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Employee findAnEmployeeByEmail(String email){
        try {
            Employee employee = employeeDao.findAnEmployeeByEmail(email);
            return  employee;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /*在发送消息时对是否发消息的用户进行过滤*/
    public String getToAddress(Department department,String type){
        try {
            JSONObject params = new JSONObject();
            params.put("departmentId",department.getId());
            List<Employee> employees = employeeDao.selectAllEmployeeByDept(params);
            String toEmail = "";

            List<OperatorConfig> operatorConfigs = operatorDao.findAllConfigByDeptId(department);
            boolean isFouned = false;

            for(int j = 0 ; j < employees.size() ;j++,isFouned = false){
                Employee tempEmp = employees.get(j);
                for(int i = 0 ; i < operatorConfigs.size();i++){
                    OperatorConfig tempConfig = operatorConfigs.get(i);
                    Operator temp = tempConfig.getOperator();
                    if(temp.getEmpId() == tempEmp.getId()){
                        isFouned = true;
                        String message = tempConfig.getMessageConfig();
                        JSONObject msgObj = JSONObject.parseObject(message);
                        if("true".equals(msgObj.getString(type))){
                            toEmail += tempEmp.getEmail() + ",";
                            break;
                        }
                    }
                }
                if(isFouned == false){
                    toEmail += tempEmp.getEmail()+",";
                }
                return toEmail;
            }
            return "";
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

}
