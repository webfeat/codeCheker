package com.project.service.permission.permissionImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.permission.ModuleDao;
import com.project.entity.permission.Module;
import com.project.service.AppService;
import com.project.service.permission.ModuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public class ModuleServiceBean extends AppService implements ModuleService {

    @Autowired
    ModuleDao moduleDao;

    public JSONObject saveModule(JSONObject params) {
        String moduleName = String.valueOf(params.get("moduleName"));
        String routeName =  String.valueOf(params.get("moduleRoute"));
        String isSystemModule =  String.valueOf(params.get("isSystemModule"));
        int parentModuleId = 0;
        if(params.get("parentModuleId") != null){
            parentModuleId = Integer.parseInt( String.valueOf(params.get("parentModuleId")));
        }
        int moduleCodeMax = moduleDao.findModuleCodeMax() + 1;

        String isUsed = String.valueOf(params.get("isUsed"));
        Module module = new Module();
        module.setIsUsed(isUsed);
        module.setModuleCode(String.valueOf(moduleCodeMax));
        module.setModuleRoute(routeName);
        module.setModuleName(moduleName);
        module.setCreateDate(new Date());
        module.setIsSystemModule(isSystemModule);
        if(parentModuleId != 0){
            module.setParentModuleId(parentModuleId);
        }

        int response = moduleDao.saveModule(module);
        JSONObject jsonObject = new JSONObject();

        if(response == 0){
            jsonObject.put("status","失败");
            jsonObject.put("message","模块新增失败");
            jsonObject.put("code",500);
        }else{
            jsonObject.put("status","成功");
            jsonObject.put("message","模块新增成功");
            jsonObject.put("code",200);
        }

        return jsonObject;
    }


    public JSONObject findModulesByParentModuleId(String parentModuleId,int operaotrId){
        if(parentModuleId == null || "".equals(parentModuleId)){
            parentModuleId = "0";
        }
        List<Module> modules = moduleDao.findModulesByParentModuleId(Integer.parseInt(parentModuleId),operaotrId);

        for (Module module:modules){
            searchModulesSubModules(module,operaotrId);
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data",modules);
        return jsonObject;
    }

    //递归查询子模块
    public void searchModulesSubModules(Module module,int operatorId){
        int moduleId = module.getId();
        List<Module> modules = moduleDao.findModulesByParentModuleId(moduleId,operatorId);

        if(modules.size() > 0){
            module.setSubModules(modules);
        }

        for(Module tempModule :modules){
            searchModulesSubModules(tempModule,operatorId);
        }
    }

}
