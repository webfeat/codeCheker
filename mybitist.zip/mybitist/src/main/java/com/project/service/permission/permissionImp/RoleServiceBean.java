package com.project.service.permission.permissionImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.permission.RoleDao;
import com.project.entity.permission.OperatorAndRole;
import com.project.entity.permission.Role;
import com.project.service.AppService;
import com.project.service.permission.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RoleServiceBean extends AppService implements RoleService {

    @Autowired
    RoleDao roleDao;

    public Boolean distributeRoleForOperator(OperatorAndRole operatorAndRole) {
        try {
           Boolean isCusses = roleDao.distributeRoleForOperator(operatorAndRole);
           return isCusses;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }


    public Role getRoleByRoleCode(String roleCode){
        try {
           Role role = roleDao.getRoleByRoleCode(roleCode);
            return role;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public JSONObject findRoleList(JSONObject params){
        try{
            String curentPage = String.valueOf(params.get("currentPage"));
            String pageNo = String.valueOf(params.get("pageNo"));

            int cuPage = Integer.parseInt(curentPage);
            int paNo = Integer.parseInt(pageNo);

            cuPage *= paNo;
            params.put("currentPage",cuPage);

            List<Role> rolelist = roleDao.findAllRoles(params);

            JSONObject jsObject = new JSONObject();
            List<Role> allRoles = roleDao.findAllRoles(jsObject);
            jsObject = new JSONObject();

            jsObject.put("totalItems",allRoles.size());
            jsObject.put("data",rolelist);
            jsObject.put("pageSize",Math.ceil(allRoles.size()/Integer.valueOf(String.valueOf(params.get("pageNo")))));
            return jsObject;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    public JSONObject updateRole(Role role) {
        JSONObject jsonObject = new JSONObject();
        try{
            int count =  roleDao.updateRole(role);
            jsonObject = getResultMap(count,"update");
            return jsonObject;
        }catch (Exception e){
            e.printStackTrace();
            jsonObject = getResultMap(0,"update");
            return jsonObject;
        }
    }

    public JSONObject insertRole(Role role) {
        JSONObject jsonObject = new JSONObject();

        try{
          int count =  roleDao.insertNewRole(role);
          if(count == 0){
              jsonObject.put("status",false);
              jsonObject.put("message","保存失败");
              jsonObject.put("code",501);
          }else if(count == 1){
              jsonObject.put("status",true);
              jsonObject.put("message","保存成功");
              jsonObject.put("code",200);
          }
          return jsonObject;
        }catch (Exception e){
            e.printStackTrace();
            return jsonObject;
        }
    }

    //删除一条数据
    public JSONObject deleteById(Role role){
        JSONObject jsonObject = new JSONObject();
        try {
            int count = roleDao.deleteRoleById(role);
            jsonObject = getResultMap(count,"delete");
            return jsonObject;
        }catch (Exception e){
            e.printStackTrace();
            return getResultMap(0,"delete");
        }
    }

    public Role findRoleById(String roleId){
        try{
          Role role = roleDao.findRoleById(roleId);
          return role;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public Role findRoleByOperatorId(int operatorId){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("operatorId",operatorId);
            return roleDao.findRoleByOperatorId(jsonObject);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


}
