package com.project.service.organization;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.organization.Department;
import org.springframework.stereotype.Service;

@Service
public interface EmployeeService {

    public abstract JSONObject registPerson(JSONObject jsonObject);

    public String getToAddress(Department department, String type);
}
