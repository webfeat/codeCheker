package com.project.service.permission;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.project.entity.permission.OperatorAndRole;
import com.project.entity.permission.Role;
import org.springframework.stereotype.Service;

@Service
public interface RoleService {
    public Boolean distributeRoleForOperator(OperatorAndRole operatorAndRole);

    public Role getRoleByRoleCode(String roleCode);

    public JSONObject findRoleList(JSONObject jsonObject);

    public JSONObject updateRole(Role role);

    public JSONObject insertRole(Role role);

    public JSONObject deleteById(Role role);

    public Role findRoleById(String roleId);

    public Role findRoleByOperatorId(int operatorId);
}
