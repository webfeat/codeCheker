package com.project.service.organization;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.organization.Employee;
import org.springframework.stereotype.Service;

/**
 * Created by samsung on 2018/4/25.
 */
@Service
public interface DepartmentService {
    public abstract JSONObject findDepartmentList(JSONObject params);

    public abstract JSONObject insertNewDepartment(JSONObject params, Employee employee);

    public abstract JSONObject deleteDepartmentById(Integer deptId,int operatorId);
}
