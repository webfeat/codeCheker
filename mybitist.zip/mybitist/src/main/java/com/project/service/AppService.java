package com.project.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.project.entity.Entity;
import com.project.util.AuthenUtil;
import com.project.util.SqlFactoryUtil;
import org.springframework.beans.factory.annotation.Autowired;

public class AppService {
    @Autowired
    protected SqlFactoryUtil sqlFactoryUtil;

    public JSONObject getResultMap(int count,String type){
        JSONObject jsonObject = new JSONObject();

        String status = "";
        String code = "";
        String message = "";

        //如果操作数量为0，那么就是保存错误
        if(count <= 0){
            status = "false";
            code = "501";
            message = "失败";
        }else{
            code = "200";
            status = "true";
            message = "成功";
        }

        if("delete".equals(type)){
            message = "删除" + message;
        }else if("add".equals(type)){
            message = "保存" + message;
        }else if("update".equals(type)){
            message = "更新" + message;
        }

        jsonObject.put(status,status);
        jsonObject.put(code,code);
        jsonObject.put(message,message);

        return jsonObject;
    }
}
