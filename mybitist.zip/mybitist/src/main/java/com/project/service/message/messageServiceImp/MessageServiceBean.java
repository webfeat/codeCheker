package com.project.service.message.messageServiceImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.message.MessageDao;
import com.project.dao.organization.DepartmentDao;
import com.project.dao.organization.EmployeeDao;
import com.project.dao.permission.OperatorDao;
import com.project.dao.view.ViewDao;
import com.project.entity.MessageView;
import com.project.entity.message.Message;
import com.project.entity.organization.Department;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import com.project.service.message.MessageService;
import com.project.util.AuthenUtil;
import com.project.util.EmailUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class MessageServiceBean implements MessageService {

    @Autowired
    AuthenUtil authenUtil;

    @Autowired
    MessageDao messageDao;

    @Autowired
    EmailUtil emailUtil;

    @Autowired
    ViewDao viewDao;

    @Autowired
    DepartmentDao departmentDao;

    @Autowired
    EmployeeDao employeeDao;

    @Autowired
    OperatorDao operatorDao;

    //设置验证码过期时间：3分钟
    private final int timeOut = 3;

    public Message sendRegistCodeMessage(String toEmial) {

        String virafiedCode = authenUtil.generateCode();

        //实例化对象
        Message message = new Message();
        message.setType("注册");
        message.setSetSubject("注册信息");
        message.setCreateDate(new Date());
        message.setEmail(toEmial);
        message.setAuthCode(virafiedCode);

        //存储到数据库
       int a = messageDao.insertAMessage(message);
        if(a == 1){
            //发送邮件
           boolean isScucess = emailUtil.sendEmail(message.getEmail(),message,"欢迎注册我们的账号，本次您的验证码为：");
            if(isScucess){
                return message;
            }else{
                return null;
            }
        }else{
            return null;
        }
    }

    //校验验证码是否过期
    public boolean isTimeOnForVeriedCode(String email,String authCode){
        try {
            Date date = new Date();
            //查出验证码消息
            Message message = messageDao.findAuthCodeByEmail(email,authCode);
            long time = date.getMinutes();
            Date codeDate = message.getCreateDate();
            long codeTime = codeDate.getMinutes();
            if(message == null){
                return false;
            }
            //判断是否过期
            long dataTime = time - codeTime;
            if(dataTime >= this.timeOut){
                return  true;
            }

            return false;
        }catch (Exception e){
            e.printStackTrace();
            return true;
        }
    }


    public JSONObject findAllTypeMessage(Operator operator,JSONObject params){
        try {
            /*第一步，查询此人的所有部门*/
            int empId = operator.getEmployee().getId();
            params.put("employeeId",empId);

            JSONObject deptParams = new JSONObject();
            deptParams.put("employeeId",params.get("employeeId"));
            List<Department> departments = departmentDao.findDepartmentList(params);
            if(departments == null || deptParams.size() <= 0){
                JSONObject result = new JSONObject();
                result.put("totalItems",0);
                result.put("pageSize",10);
                result.put("status",true);
                result.put("data",new ArrayList<MessageView>());
                result.put("code",200);
            }

            int[] deptIds = new int[departments.size()];
            int size = 0;
            for (int i = 0 ; i < departments.size() ;i++){
                deptIds[i] = departments.get(i).getId();
                size++;
            }

            //此参数用于查询消息视图
            params.put("departmentIds",deptIds);

            List<MessageView> list = viewDao.findMessageMap(params);
            JSONObject parms2 = new JSONObject();
            parms2.put("departmentIds",deptIds);
            List<MessageView> all = viewDao.findMessageMap(parms2);

           JSONObject result = new JSONObject();
            result.put("totalItems",all.size());
            result.put("pageSize",Math.ceil(all.size()/Integer.valueOf(String.valueOf(params.get("pageNo")))));
           result.put("status",true);
           result.put("data",list);
           result.put("code",200);
           return result;
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("status",false);
            error.put("code",500);
            return error;
        }
    }


    public JSONObject countScoresSubmit(JSONObject params){
        try {
            List<Integer> submited = messageDao.countScoresByMessageId(params);
            List<Employee> employees = employeeDao.selectAllEmployeeByDept(params);
            int[] ids = new int[employees.size()];

            for(int i = 0 ; i < employees.size();i++){
                ids[i] = employees.get(i).getId();
            }
            params.put("empIds",ids);
            List<Operator> operators = operatorDao.findOperatorByEmployeeIds(params);
            List<Employee> data = new ArrayList<Employee>();

            Map<String,String> nameMapper = new HashMap<String, String>();
            for (int i = 0 ; i < submited.size();i++){
                for (int j = 0 ; j < operators.size() ;j++){
                    if(submited.get(i) == operators.get(j).getId()){
                        nameMapper.put(operators.get(j).getUsername(),operators.get(j).getEmployee().getName());
                        data.add(operators.get(j).getEmployee());
                        employees.remove(operators.get(j).getEmployee());
                        break;
                    }
                }
            }

            JSONObject result = new JSONObject();
            result.put("submits",data);
            result.put("nameMapper",nameMapper);
            result.put("allSubmits",employees);
            result.put("message","完成");
            result.put("code",200);
            return result;
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("message","失败");
            error.put("code",500);
            return error;
        }
    }

}
