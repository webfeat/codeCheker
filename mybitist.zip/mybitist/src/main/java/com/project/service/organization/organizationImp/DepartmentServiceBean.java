package com.project.service.organization.organizationImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.organization.DepartmentDao;
import com.project.entity.organization.Department;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Role;
import com.project.service.organization.DepartmentService;
import com.project.util.AuthenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * Created by samsung on 2018/4/25.
 */
@Repository
public class DepartmentServiceBean implements DepartmentService {

    @Autowired
    private DepartmentDao departmentDao;

    public JSONObject findDepartmentList(JSONObject params) {

        JSONObject jsonObject = new JSONObject();
        try {
            String curentPage = String.valueOf(params.get("currentPage"));
            String pageNo = String.valueOf(params.get("pageNo"));

            int cuPage = Integer.parseInt(curentPage);
            int paNo = Integer.parseInt(pageNo);

            cuPage *= paNo;
            params.put("currentPage",cuPage);

            //查询所有班级的列表
            List<Department> departmentLists = departmentDao.findDepartmentList(params);

            JSONObject jsObject = new JSONObject();
            int employeeId = Integer.parseInt(String.valueOf(params.get("employeeId")));

            jsonObject.put("employeeId",employeeId);//作为参数查询关于具体到人的所在或所属班级
            List<Department> allRoles = departmentDao.findDepartmentList(jsonObject);
            jsObject = new JSONObject();
            jsObject.put("totalItems",allRoles.size());
            jsObject.put("data",departmentLists);
            jsObject.put("pageSize",Math.ceil(allRoles.size()/Integer.valueOf(String.valueOf(params.get("pageNo")))));

            jsObject.put("status",true);
            jsObject.put("code",200);
            return jsObject;
        }catch (Exception e){
            e.printStackTrace();
            jsonObject.put("status",false);
            jsonObject.put("data",null);
            jsonObject.put("message","失败");
            jsonObject.put("code",501);
            return jsonObject;
        }
    }

    public JSONObject insertNewDepartment(JSONObject params, Employee employee) {
        try {
            //从参数中获取department的值
            String deptName = String.valueOf(params.get("deptName"));
            String depPhoneNum = String.valueOf(params.get("depPhoneNum"));
            String orgName = String.valueOf(params.get("orgName"));//获取院校名称
            String orgCode = String.valueOf(params.get("orgCode"));//获取院校编码

            String applyCode = AuthenUtil.getStringRandom(6);
            String deptCode = AuthenUtil.getStringRandom(10);

            //设置部门的一些属性
            Department department = new Department();
            department.setDepPhoneNum(depPhoneNum);
            department.setDeptName(deptName);
            department.setOrgName(orgName);
            department.setApplyCode(applyCode);
            department.setCreateDate(new Date());
            department.setCode(orgCode + "//" + deptCode);
            department.setEmployeeId(employee.getId());
            department.setOrgpId(1);//目前先设置默认单位1
            JSONObject jsonObject = new JSONObject();

            //插入记录
            int count = departmentDao.insertNewDepartment(department);
            if(count < 1){
                jsonObject.put("status",false);
                jsonObject.put("message","添加失败");
                jsonObject.put("code",500);
            }else{
                jsonObject.put("status",true);
                jsonObject.put("message","添加成功");
                jsonObject.put("code",200);
            }
            return jsonObject;
        }catch (Exception e){
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("status",false);
            jsonObject.put("message","添加失败");
            jsonObject.put("code",500);
            return jsonObject;
        }
    }

    public JSONObject deleteDepartmentById(Integer deptId,int operatorId) {
        try {
            JSONObject params = new JSONObject();
            params.put("operatorId",operatorId);
            params.put("departmentId",deptId);
           int count = departmentDao.deleteDepartmentById(deptId,params);
           if(count <= 0){
               JSONObject jsonObject = new JSONObject();
               jsonObject.put("status",false);
               jsonObject.put("message","删除失败");
               jsonObject.put("code",500);
               return jsonObject;
           }else{
               JSONObject jsonObject = new JSONObject();
               jsonObject.put("status",true);
               jsonObject.put("message","删除成功");
               jsonObject.put("code",200);
               return  jsonObject;
           }
        }catch (Exception e){
            e.printStackTrace();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("status",false);
            jsonObject.put("message","删除失败");
            jsonObject.put("code",500);
            return  jsonObject;
        }
    }
}
