package com.project.service.permission;

import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Service;

@Service
public interface ModuleService {

    public abstract JSONObject saveModule(JSONObject params);

    public abstract JSONObject findModulesByParentModuleId(String parentModuleId,int operatorId);

}
