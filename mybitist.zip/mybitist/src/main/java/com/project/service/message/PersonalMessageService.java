package com.project.service.message;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.organization.Department;
import com.project.entity.permission.Operator;
import org.springframework.stereotype.Service;

/**
 * Created by samsung on 2018/5/10.
 */
@Service
public interface PersonalMessageService {
        public JSONObject insertNewPersonalMessage(JSONObject jsonObject, Operator operator, Department department);

        public JSONObject selectAllMessages(JSONObject jsonObject, Operator operator);
}
