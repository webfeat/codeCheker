package com.project.service.message.messageServiceImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.message.MessageDao;
import com.project.dao.message.PersonalMessageDao;
import com.project.dao.message.WorkScoreDao;
import com.project.entity.message.Message;
import com.project.entity.message.MessageWork;
import com.project.entity.message.PersonMessage;
import com.project.entity.message.WorkScore;
import com.project.entity.organization.Department;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import com.project.service.AppService;
import com.project.service.message.PersonalMessageService;
import com.project.util.EmailUtil;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Repository
public class PersonalMessageServiceBean extends AppService implements PersonalMessageService {

    @Resource
    private PersonalMessageDao personalMessageDao;

    @Resource
    MessageDao messageDao;

    @Resource
    EmailUtil emailUtil;

    @Resource
    WorkScoreDao workScoreDao;

    /*老师发布作业消息*/
    public JSONObject insertNewPersonalMessage(JSONObject jsonObject, Operator operator, Department department){
        try {
            //获取需要的参数
            String content = String.valueOf(jsonObject.get("content"));
            String title = String.valueOf(jsonObject.get("title"));
            int operatorId = operator.getId();
            int deptId = department.getId();
            Date endTime = (Date)jsonObject.get("endTime");

            //获取上传路径
            String uploadPath = String.valueOf(jsonObject.get("uploadPath"));

            //部门ID
            JSONObject params = new JSONObject();
            params.put("departmentId",deptId);
            String emails = personalMessageDao.findAllSendEmpsEmails(params);

            //设置发送消息类型
            Employee employee = operator.getEmployee();
            PersonMessage personMessage = new PersonMessage();
            personMessage.setTitle(title);
            personMessage.setContent(content);
            personMessage.setDeptId(deptId);
            personMessage.setEndTime(endTime);
            personMessage.setFrom(employee.getName());
            personMessage.setSendOperatorId(operator.getId());
            personMessage.setUploadPath(uploadPath);
            personMessage.setCreateDate(new Date());
            personMessage.setTo(emails);

            //插入消息记录
           int  count = personalMessageDao.InsertWorkMessage(personMessage);

           String msg = employee.getName() + "在" + new Date().toString() + "时发布了作业，请及时登陆查看";
            boolean isSended  = emailUtil.sendMessageEmail(emails,"通知",msg);
            if(isSended){
                JSONObject successObj = new JSONObject();
                successObj.put("status",true);
                successObj.put("message","发送成功");
                return successObj;
            }else{
                JSONObject errorObj = new JSONObject();
                errorObj.put("status",false);
                errorObj.put("message","发送失败");
                return errorObj;
            }
        }catch (Exception e){
            e.printStackTrace();
            JSONObject errorObj = new JSONObject();
            errorObj.put("status",false);
            errorObj.put("message","发送失败");
            return errorObj;
        }
    }

    public JSONObject selectAllMessages(JSONObject jsonObject, Operator operator) {
        try {
            String currentPage = jsonObject.getString("currentPage");
            String pageSize = jsonObject.getString("pageSize");
            String type = jsonObject.getString("type");
            String departmentId = jsonObject.getString("departmentId");
            int currentOpt = 0;
            if(jsonObject.containsKey("currentOpt")){
                currentOpt = jsonObject.getInteger("currentOpt");
            }

            int currentPageNum = Integer.parseInt(currentPage);
            int pageSizeNum = Integer.parseInt(pageSize);
            if(currentPageNum <= 0){
                currentPageNum = 0;
            }else{
                currentPageNum = currentPageNum -1;
            }

            //分页查询
            JSONObject params = new JSONObject();
            params.put("operatorId",operator.getId());
            params.put("type",type);
            params.put("departmentId",Integer.parseInt(departmentId));
            List<MessageWork> all = messageDao.findAllMessageList(params);

            //查询总数
            params.put("currentPage",pageSizeNum * currentPageNum);
            params.put("pageNo",pageSizeNum);
            List<MessageWork> list = messageDao.findAllMessageList(params);

            if(currentOpt > 0){
                for(int i = 0 ; i < list.size();i++){
                    MessageWork temp = list.get(i);
                    JSONObject tempParams = new JSONObject();
                    tempParams.put("workmessageId",temp.getId());
                    tempParams.put("currentOpt",currentOpt);
                    List<WorkScore> workScores = workScoreDao.findScoreByWorkMessageId(tempParams);
                    if(workScores != null && workScores.size() > 0){
                        temp.setWorkScores(workScores);
                    }
                }
            }

            JSONObject resultObj = new JSONObject();
            resultObj.put("status",false);
            resultObj.put("message","查询成功");
            resultObj.put("data",list);
            resultObj.put("total",all.size());
            return resultObj;
        }catch (Exception e){
            e.printStackTrace();
            JSONObject errorObj = new JSONObject();
            errorObj.put("status",false);
            errorObj.put("message","查询失败");
            return errorObj;
        }
    }
}
