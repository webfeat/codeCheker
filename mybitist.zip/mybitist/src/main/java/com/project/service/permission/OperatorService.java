package com.project.service.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.permission.Operator;
import org.springframework.stereotype.Service;

@Service
public interface OperatorService {
    public Operator saveOperator(Operator operator);

    public Operator findOperatorByUserName(String username);

    public Operator validateOperator(JSONObject jsonObject);

}
