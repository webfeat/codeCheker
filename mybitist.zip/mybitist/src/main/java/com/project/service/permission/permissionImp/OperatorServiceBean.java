package com.project.service.permission.permissionImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.permission.OperaotorConfigDao;
import com.project.dao.permission.OperatorDao;
import com.project.entity.OperatorConfig;
import com.project.entity.permission.Operator;
import com.project.service.AppService;
import com.project.service.permission.OperatorService;
import com.project.util.Aes;
import com.project.util.AuthenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public class OperatorServiceBean extends AppService implements OperatorService {

    @Autowired
    OperatorDao operatorDao;

    @Autowired
    OperaotorConfigDao operaotorConfigDao;

    private AuthenUtil authenUtil = new AuthenUtil();

    public Operator saveOperator(Operator operator) {
        try {
            operator = operatorDao.saveOperator(operator);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message",true);
            jsonObject.put("empChange",true);
            jsonObject.put("workEnd",true);
            jsonObject.put("workBublish",true);
            String messageConfig = jsonObject.toJSONString();

            OperatorConfig operatorConfig = new OperatorConfig();
            operatorConfig.setMessageConfig(messageConfig);
            operatorConfig.setCreateDate(new Date());
            operatorConfig.setOperatorId(operator.getId());

            int count = operaotorConfigDao.insertOperatorConfig(operatorConfig);

            return operator;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Operator findOperatorByUserName(String username) {
        try {
            Operator operator = operatorDao.findOperatorByUserName(username);
            return operator;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    //校验过程，先查出操作员，对操作员密码进行转换比较
    public Operator validateOperator(JSONObject jsonObject) {
        try {
            if (jsonObject != null && !"".equals(jsonObject.get("password")) && jsonObject.get("password") != null) {
                Operator operator = operatorDao.findOperatorByUserName(String.valueOf(jsonObject.get("userName")));
                String copyed = String.valueOf(jsonObject.get("password"));
                if (operator != null) {
                    String password = Aes.aesDecrypt(operator.getPassword());
                    if (password != null && password.equals(copyed)) {
                        return operator;
                    } else {
                        return null;
                    }
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
