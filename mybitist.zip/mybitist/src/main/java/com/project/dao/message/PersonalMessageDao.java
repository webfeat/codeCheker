package com.project.dao.message;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.message.Attachment;
import com.project.entity.message.PersonMessage;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PersonalMessageDao  {
    public int InsertWorkMessage(PersonMessage personMessage);

    public int insertAttachment(Attachment attachment);

    public String findAllSendEmpsEmails(JSONObject jsonObject);

    public List<Attachment> findAllAttachement(JSONObject jsonObject);
}
