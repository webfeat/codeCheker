package com.project.dao.organization.organizationImp;

import com.project.dao.organization.OrganizationDao;
import org.springframework.stereotype.Repository;

@Repository
public class OrganizationDaoBean implements OrganizationDao {
}
