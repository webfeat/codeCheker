package com.project.dao.organization;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.organization.Employee;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface EmployeeDao {
    public abstract Employee saveEmployee(Employee employee) throws Exception;

    public Employee findAnEmployeeByEmail(String email) ;

    public Employee updateEmployee(Employee employee);

    public Employee getEmployeeById(Integer employeeId);

    public List<Employee> selectAllEmployeeByDept(JSONObject params);
}
