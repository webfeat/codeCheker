package com.project.dao.message;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.message.mapper.MessageMapper;
import com.project.entity.message.Message;
import com.project.entity.message.WorkScore;
import com.project.util.SqlFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public interface WorkScoreDao{
    public int insertScore(WorkScore workScore);

    public int updateScore(WorkScore workScore);

    public List<WorkScore> findScoreByWorkMessageId(JSONObject params);
}
