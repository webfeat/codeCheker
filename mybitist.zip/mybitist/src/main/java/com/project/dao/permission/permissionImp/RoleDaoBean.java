package com.project.dao.permission.permissionImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.permission.RoleDao;
import com.project.dao.permission.mapper.RoleMapper;
import com.project.entity.permission.OperatorAndRole;
import com.project.entity.permission.Role;
import com.project.entity.permission.RoleAndPermission;
import com.project.util.SqlFactoryUtil;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RoleDaoBean extends AppDao implements RoleDao {

    @Autowired
    SqlFactoryUtil sqlFactoryUtil;

    /*mapper的命名空间*/
    private String namespace = "com.project.dao.permission.mapper.RoleMapper";

    //通过ID查找到角色
    public Role getRoleByRoleId(Integer roleId) throws Exception{
        SqlSession sqlSession = sqlFactoryUtil.openSession();
        RoleMapper roleMapper = sqlSession.getMapper(RoleMapper.class);
        Role role = roleMapper.getRoleByRoleId(roleId);
        sqlSession.close();
        return role;
    }

    //通过角色编码查找到角色
    public Role getRoleByRoleCode(String code) throws Exception{
        SqlSession sqlSession = sqlFactoryUtil.openSession();
        RoleMapper roleMapper = sqlSession.getMapper(RoleMapper.class);

        Role role = roleMapper.getRoleByRoleCode(code);
        sqlSession.close();
        return role;
    }

    //给角色分配权限点
    public Boolean distributePermissionForRole(RoleAndPermission roleAndPermission) throws Exception{
        SqlSession sqlSession = sqlFactoryUtil.openSession();
        int count = sqlSession.insert("com.project.dao.permission.mapper.RoleMapper.distributePermissionForRole",roleAndPermission);
        sqlSession.commit();
        sqlSession.close();
        if(count > 0){
            return true;
        }else{
            return false;
        }
    }

    //给操作员分配角色
    public Boolean distributeRoleForOperator(OperatorAndRole operatorAndRole) throws Exception{
        SqlSession sqlSession = sqlFactoryUtil.openSession();
        int count = sqlSession.insert("com.project.dao.permission.mapper.RoleMapper.distributeRoleForOperator",operatorAndRole);
        sqlSession.commit();
        sqlSession.close();
        if(count > 0){
            return true;
        }else{
            return false;
        }
    }

    //查询所有的角色，表格使用
    public List<Role> findAllRoles(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Object test = JSONObject.toJSON(params);
            List<Role> roles = sqlSession.selectList("com.project.dao.permission.mapper.RoleMapper.findRoleList",test);
            sqlSession.close();
            return roles;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /*新增一条角色记录*/
    public int insertNewRole(Role role){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert("com.project.dao.permission.mapper.RoleMapper.insertRole",role);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public int updateRole(Role role) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.update("com.project.dao.permission.mapper.RoleMapper.updateRole",role);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public int deleteRoleById(Role role ){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.delete(namespace + ".delteById",role);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public Role findRoleById(String RoleId){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Role role = sqlSession.selectOne(namespace + ".findRoleById",RoleId);
            sqlSession.close();
            return role;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    public Role findRoleByOperatorId(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Role role = sqlSession.selectOne(namespace + ".findRoleByOperatorId",params);
            return role;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
