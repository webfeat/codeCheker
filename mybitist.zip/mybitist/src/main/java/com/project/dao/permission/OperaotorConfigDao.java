package com.project.dao.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.OperatorConfig;
import com.project.entity.permission.Operator;
import org.springframework.stereotype.Service;

/**
 * Created by samsung on 2018/5/4.
 */
@Service
public interface OperaotorConfigDao {
    public abstract OperatorConfig findOperatorConfigByOperatorId(int operatorId,int departmentId);

    public abstract int updateOperatorConfig(OperatorConfig operatorConfig);

    public abstract int insertOperatorConfig(OperatorConfig operatorConfig);

    public abstract OperatorConfig findOperatorConfig(JSONObject params);
}
