package com.project.dao.message.messageImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.message.WorkScoreDao;
import com.project.entity.message.WorkScore;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class WorkScoreDaoBean extends AppDao implements WorkScoreDao {
    private String nameSpace = "com.project.dao.message.mapper.workScore";

    public int insertScore(WorkScore workScore){
        return this.inseartEntity(nameSpace + ".insertScore",workScore);
    }

    public int updateScore(WorkScore workScore) {
        return this.updateEntity(nameSpace + ".updateScore",workScore);
    }

    public List<WorkScore> findScoreByWorkMessageId(JSONObject params) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<WorkScore> list = sqlSession.selectList(nameSpace + ".findScoreByWorkMessageId",params);
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
