package com.project.dao.message;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.message.Message;
import com.project.entity.message.MessageWork;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MessageDao {

    public int insertAMessage(Message message);

    public Message findAuthCodeByEmail(String email,String authCode);

    public List<MessageWork> findAllMessageList(JSONObject params);

    public int publishMessageWork(MessageWork messageWork);

    public MessageWork findMessageWorkById(JSONObject params);

    public int updateMessageWork(MessageWork messageWork);

    public List<MessageWork> selectMessageForWelcome(JSONObject params);

    public JSONObject countPipe(JSONObject params);

    public List<MessageWork> findCLearlyMessage(JSONObject params);


    public List<Integer> selectFinished(JSONObject params);
    
    public List<Integer> findSendMessage(JSONObject params);

    public List<Integer> countScoresByMessageId(JSONObject params);

    public List<MessageWork> findSendMessageGrid(JSONObject params);
}
