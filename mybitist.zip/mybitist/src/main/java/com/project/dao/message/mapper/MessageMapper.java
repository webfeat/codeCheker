package com.project.dao.message.mapper;

import com.project.entity.message.Message;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

public interface MessageMapper {

    public void insertMessage(Message message);

    public Message findAuthCodeByEmail(Map<String,String> params);
}
