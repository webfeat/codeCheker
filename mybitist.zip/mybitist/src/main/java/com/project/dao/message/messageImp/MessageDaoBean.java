package com.project.dao.message.messageImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.message.MessageDao;
import com.project.dao.message.mapper.MessageMapper;
import com.project.entity.message.Message;
import com.project.entity.message.MessageWork;
import com.project.util.SqlFactoryUtil;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class MessageDaoBean implements MessageDao {

    @Autowired
    SqlFactoryUtil sqlFactoryUtil;

    @Autowired
    MessageDao messageDao;

    private String nameSpace = "com.project.dao.message.mapper.MessageMapper";

    public int insertAMessage(Message message){
        SqlSession sqlSession = null;
        try {
            sqlSession = sqlFactoryUtil.openSession();
            MessageMapper messageMapper = sqlSession.getMapper(MessageMapper.class);
            messageMapper.insertMessage(message);
            sqlFactoryUtil.commitSession();
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }finally {
            sqlSession.close();
        }
        return 1;
    }

    //查找验证码
    public Message findAuthCodeByEmail(String email,String authCode){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            MessageMapper messageMapper = sqlSession.getMapper(MessageMapper.class);

            Map<String,String> map = new HashMap<String, String>();
            map.put("email",email);
            map.put("authCode",authCode);


            Message message = messageMapper.findAuthCodeByEmail(map);
            return message;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /*查询教师发布的所有作业*/
    public List<MessageWork> findAllMessageList(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<MessageWork> list = sqlSession.selectList(nameSpace+".findAllMessage",params);
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int publishMessageWork(MessageWork messageWork) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert(nameSpace + ".publishWork",messageWork);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    /*根据messageID查询记录*/
    public MessageWork findMessageWorkById(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            MessageWork messageWork = sqlSession.selectOne(nameSpace + ".findMessageWorkById",params);
            sqlSession.close();
            return messageWork;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int updateMessageWork(MessageWork messageWork){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.update(nameSpace + ".updateMessageWork",messageWork);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public List<MessageWork> selectMessageForWelcome(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<MessageWork> messageWorks = sqlSession.selectList(nameSpace + ".selectMessageForWelcome",params);
            sqlSession.close();
            return messageWorks;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /*查询首页三张表的接口*/
    public JSONObject countPipe(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List subOptIds = sqlSession.selectList(nameSpace + ".selectSubmited",params);
            List unSubOptIds = sqlSession.selectList(nameSpace + ".selectunSubmited",params);
            sqlSession.close();
            JSONObject result = new JSONObject();
            result.put("subOptIds",subOptIds);
            result.put("unSubOptIds",unSubOptIds);
            return result;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<MessageWork> findCLearlyMessage(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<MessageWork> messageWorks = sqlSession.selectList(nameSpace + ".findCLearlyMessage",params);
            sqlSession.close();
            return messageWorks;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Integer> selectFinished(JSONObject params) {
        try {

            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List messageWorks = sqlSession.selectList(nameSpace+".selectFinished",params);
            sqlSession.close();
            return messageWorks;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Integer> findSendMessage(JSONObject params) {
        try {

            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List messageWorks = sqlSession.selectList(nameSpace+".findSendMessage",params);
            sqlSession.close();
            return messageWorks;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    public List<Integer> countScoresByMessageId(JSONObject params) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<Integer> result = sqlSession.selectList("com.project.dao.message.mapper.workScore.countScoresByMessageId",params);
            return result;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<MessageWork> findSendMessageGrid(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<MessageWork> messageWorks = sqlSession.selectList(nameSpace + ".findSendMessageGrid",params);
            return messageWorks;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
