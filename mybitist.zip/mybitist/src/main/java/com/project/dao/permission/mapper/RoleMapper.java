package com.project.dao.permission.mapper;

import com.project.entity.permission.Role;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

public interface RoleMapper {

    @Select("select * from role where id = #{roleId}")
    public abstract Role getRoleByRoleId(Integer roleId);

    @Select("select * from role where code = #{code}")
    public abstract Role getRoleByRoleCode(String code);
}
