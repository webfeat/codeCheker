package com.project.dao.organization;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.organization.Department;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public interface DepartmentDao {

   public abstract Department getDepartmentById(int id);

    public List<Department> findDepartmentList(JSONObject jsonObject);

    public int insertNewDepartment(Department department);

    public int deleteDepartmentById(int deptId,JSONObject params);

    public Department selectClassByApplyCode(String applyCode);
    public int insertEmpAndDept(JSONObject params);
    public Map selectRecoverJoin(JSONObject result);

    public int delteEmpAndDept(JSONObject params);

    public List<Department> getDepartmentsJoined(JSONObject jsonObject);

}
