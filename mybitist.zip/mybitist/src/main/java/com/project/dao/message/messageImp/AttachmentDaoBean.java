package com.project.dao.message.messageImp;

import com.project.dao.message.AttachmentDao;
import com.project.entity.message.Attachment;
import com.project.service.AppService;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

/**
 * Created by samsung on 2018/5/21.
 */
@Repository
public class AttachmentDaoBean extends AppService implements AttachmentDao {
    private String nameSpace = "com.project.dao.message.mapper.PersonalMessageMapper";

    /*添加附件*/
    public int insertAttachment(Attachment attachment){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert(nameSpace + ".insertAttachment",attachment);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

}
