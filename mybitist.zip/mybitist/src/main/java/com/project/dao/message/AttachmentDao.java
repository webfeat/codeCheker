package com.project.dao.message;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.message.Attachment;
import com.project.entity.message.Message;
import com.project.entity.message.MessageWork;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface AttachmentDao {
    public int insertAttachment(Attachment attachment);
}
