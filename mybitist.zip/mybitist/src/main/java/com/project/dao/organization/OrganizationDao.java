package com.project.dao.organization;

import org.springframework.stereotype.Service;

@Service
public interface OrganizationDao {
}
