package com.project.dao.permission.permissionImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.permission.OperaotorConfigDao;
import com.project.entity.OperatorConfig;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

/**
 * Created by samsung on 2018/5/4.
 */
@Repository
public class OperaotrConfigDaoBean extends AppDao implements OperaotorConfigDao{

    private String namespace = "operatorConfig";

    public OperatorConfig findOperatorConfigByOperatorId(int operatorId,int departmentId) {
        try {
            SqlSession  sqlSession = sqlFactoryUtil.openSession();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("operatorId",operatorId);
            jsonObject.put("departmentId",departmentId);
            OperatorConfig operatorConfig = sqlSession.selectOne(namespace + ".findConfigByOperatorId",jsonObject);
            sqlSession.close();
            return operatorConfig;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int updateOperatorConfig(OperatorConfig operatorConfig) {
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.update(namespace + ".updateOperatorConfig",operatorConfig);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public int insertOperatorConfig(OperatorConfig operatorConfig) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert(namespace + ".insertOperatorConfig",operatorConfig);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public OperatorConfig findOperatorConfig(JSONObject params) {
        try {
            OperatorConfig operatorConfig = (OperatorConfig) this.findEntityByParams(namespace + ".findConfigByOperatorId",params);
            return operatorConfig;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
