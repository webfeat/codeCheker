package com.project.dao.view;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.MessageView;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by samsung on 2018/6/4.
 */
@Service
public interface ViewDao {
    /*查询所有消息的视图*/
    public List<MessageView> findMessageMap(JSONObject params);
}
