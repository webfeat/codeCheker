package com.project.dao.permission.permissionImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.permission.PermissionDao;
import com.project.entity.Entity;
import com.project.entity.permission.Permission;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class PermissionDaoBean extends AppDao implements PermissionDao {

    private String nameSpace = "permission";

    public Permission findPermissionById(int permissionId) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Permission permission = sqlSession.selectOne(nameSpace+ ".findPermissionById",permissionId);
            sqlSession.close();
            return permission;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public Permission findPermissionByCode(String code) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("code",code);

            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Permission permission = sqlSession.selectOne(nameSpace+ ".findPermissionByCode",jsonObject);
            sqlSession.close();
            return permission;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Permission> findPermissions(JSONObject jsonObject) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<Permission> list = sqlSession.selectList(nameSpace + ".findPermissionList",jsonObject);
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int savePermission(Permission permission,JSONObject params) {
        SqlSession sqlSession = null;
        try {
            sqlSession = sqlFactoryUtil.openSession();

            //保存刚刚新增的权限
            int count = sqlSession.insert(nameSpace + ".savePermission",permission);
            sqlSession.commit();
            sqlSession.close();
            //查找出刚才添加的
            Permission saved = this.findPermissionByCode(permission.getCode());
            //获取id
            int permissionId = saved.getId();
            params.put("permissionId",permissionId);
            //插入中间表
            sqlSession = sqlFactoryUtil.openSession();
            int count2 = sqlSession.insert(nameSpace + ".insertPermissionAndModule",params);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            sqlSession.rollback();
        }
        return 0;
    }

    public int insertModulePermission(JSONObject params){
        SqlSession sqlSession = null;
        try {
            sqlSession = sqlFactoryUtil.openSession();
            int count2 = sqlSession.insert(nameSpace + ".insertPermissionAndModule",params);
            sqlSession.commit();
            sqlSession.close();
            return count2;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }


    public Map<String, Object> selectPermissionAndModule(JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            return sqlSession.selectMap(nameSpace + ".selectPermissionAndModule",params,"permissionId");
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int updatePermission(Permission permission,JSONObject params) {
        SqlSession sqlSession = null;
        try {
            sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.update(nameSpace + ".updatePermission",permission);
            sqlSession.commit();

            Map<String,Object> reuslt = this.selectPermissionAndModule(params);
            if(reuslt == null || reuslt.size() == 0){
                params.put("permissionId",permission.getId());
                params.put("createDate",new Date());
                this.insertModulePermission(params);
            }else{
                int count2 = sqlSession.update(nameSpace + ".updatePermissionAndModule",params);
                sqlSession.commit();
            }
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            sqlSession.close();
        }
        return 0;
    }

    public int deletePermission(int permissionId) {
        try {
        SqlSession sqlSession = sqlFactoryUtil.openSession();
        int count = sqlSession.delete(nameSpace + ".deletePermissionById",permissionId);
        sqlSession.commit();
        sqlSession.close();
        return count;
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }

    public List<Permission> selectByRoleId(int roleId) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<Permission> list = sqlSession.selectList(nameSpace + ".selectByRoleId",roleId);
            sqlSession.commit();
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Permission> noSelectedByRoleId(String[] ids) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("permissionIds",ids);
            List<Permission> list = sqlSession.selectList(nameSpace + ".noSelectedByRoleId",jsonObject);
            sqlSession.commit();
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /*权限分配工作*/
    public int distributePermission(String newPermissions,int roleId){
        SqlSession sqlSession = null;
        try {
            sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.delete(nameSpace + ".deleteDistributePermission",roleId);

            if(count >= 0){
                String[] permissionIds = newPermissions.split(",");
                for(int i = 0 ; i < permissionIds.length ;i++){
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("createDate",new Date());
                    jsonObject.put("roleId",roleId);
                    jsonObject.put("permissionId",permissionIds[i]);
                    sqlSession.insert(nameSpace + ".distributePermission",jsonObject);
                }
                sqlSession.commit();
                return permissionIds.length;
            }
        }catch (Exception e){
            e.printStackTrace();
            sqlSession.rollback();
            return 0;
        }
        return 0;
    }

}
