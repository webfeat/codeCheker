package com.project.dao.permission.permissionImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.permission.OperatorDao;
import com.project.entity.Entity;
import com.project.entity.OperatorConfig;
import com.project.entity.organization.Department;
import com.project.entity.permission.Operator;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
public class OperatorDaoBean extends AppDao implements OperatorDao {

    private static final String namaSpace = "com.project.dao.permission.mapper.OperatorMapper";

    public Operator selectByEmployeeId(Integer empId) throws Exception{
        SqlSession sqlSession = sqlFactoryUtil.openSession();
        Operator operator = sqlSession.selectOne("com.project.dao.permission.mapper.OperatorMapper.selectByEmployeeId",empId);
        return operator;
    }

    public Operator saveOperator(Operator operator){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert("com.project.dao.permission.mapper.OperatorMapper.saveOperator",operator);
           sqlSession.commit();
            if(count == 0){
                return null;
            }
            return selectByEmployeeId(operator.getEmpId());
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public Operator findOperatorByUserName(String username) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Operator operator = sqlSession.selectOne("com.project.dao.permission.mapper.OperatorMapper.findOperatorByUserName",username);
            return operator;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    //登录校验
    public Operator validateOperator(JSONObject jsonObject) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Operator operator = sqlSession.selectOne("com.project.dao.permission.mapper.OperatorMapper.validateOperator",jsonObject);
            sqlSession.close();
            return operator;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Operator> findOperatorList(JSONObject params) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<Operator> list = sqlSession.selectList(namaSpace + ".findOperatorList",params);
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public Operator findOperatorByEmployeeId(int empId){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Operator operator = sqlSession.selectOne(namaSpace + ".findOperatorByEmployeeId",empId);
            return operator;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public Operator updateOperator(Operator operator) {
        try {
            operator.setUpdateDate(new Date());
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.update(namaSpace + ".updateOperator",operator);
            sqlSession.commit();
            sqlSession.close();
            return operator;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /*查询某一个部门所有学员的个人配置*/

    public List<OperatorConfig> findAllConfigByDeptId(Department department){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
           List<OperatorConfig> result = sqlSession.selectList("operatorConfig.selectOperatorConfigByDepAndEmp",department);
           return result;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Operator> findOperatorByEmployeeIds(JSONObject params) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<Operator> operators = sqlSession.selectList(namaSpace + ".findOperatorByEmployeeIds",params);
            return operators;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
