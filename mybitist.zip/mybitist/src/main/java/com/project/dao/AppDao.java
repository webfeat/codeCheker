package com.project.dao;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.Entity;
import com.project.util.SqlFactoryUtil;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class AppDao {

    @Autowired
    protected SqlFactoryUtil sqlFactoryUtil;

    public List<Entity> findEntityList(String nameSpace,JSONObject jsonObject){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<Entity> list = sqlSession.selectList(nameSpace,jsonObject);
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public Entity findEntityByParams(String nameSpace,JSONObject jsonObject){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Entity entity = sqlSession.selectOne(nameSpace,jsonObject);
            sqlSession.close();
            return entity;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int inseartEntity(String nameSpace,Entity entity){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert(nameSpace,entity);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public int updateEntity(String nameSpace,Entity entity){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.update(nameSpace,entity);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }
}
