package com.project.dao.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.permission.OperatorAndRole;
import com.project.entity.permission.Role;
import com.project.entity.permission.RoleAndPermission;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RoleDao {
    public Role getRoleByRoleId(Integer roleId)  throws Exception;

    public Role getRoleByRoleCode(String code) throws Exception;

    public Boolean distributePermissionForRole(RoleAndPermission roleAndPermission) throws Exception;

    public Boolean distributeRoleForOperator(OperatorAndRole operatorAndRole) throws Exception;

    public List<Role> findAllRoles(JSONObject params);

    public int insertNewRole(Role role);

    public int updateRole(Role role);

    public int deleteRoleById(Role role );

    public Role findRoleById(String roleId);

    public Role findRoleByOperatorId(JSONObject params);
}
