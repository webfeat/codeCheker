package com.project.dao.organization.organizationImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.organization.DepartmentDao;
import com.project.entity.organization.Department;
import com.project.util.SqlFactoryUtil;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class DepartmentDaoBean extends AppDao implements DepartmentDao{

    private String namespace = "dept";

    public Department getDepartmentById(int id) {
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Department department = sqlSession.selectOne("dept.getDepartmentById",id);
            sqlSession.close();
            return department;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public List<Department> findDepartmentList(JSONObject jsonObject){
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Object params = JSONObject.toJSON(jsonObject);
            List<Department> depts = sqlSession.selectList(namespace + ".getDepartments",params);
            List<Department> deptsJoin = sqlSession.selectList(namespace + ".getDepartmentsJoined",params);
            depts.addAll(deptsJoin);
            sqlSession.close();
            return depts;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }



    public List<Department> getDepartmentsJoined(JSONObject jsonObject){
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Object params = JSONObject.toJSON(jsonObject);
            List<Department> deptsJoin = sqlSession.selectList(namespace + ".getDepartmentsJoined",params);
            sqlSession.close();
            return deptsJoin;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int insertNewDepartment(Department department){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert("dept.insertNewDepartment",department);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public int deleteDepartmentById(int deptId,JSONObject params){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.delete("dept.deleteDepartmentById",deptId);
            int count2 = sqlSession.delete("operatorConfig.deleteByOptIdAndEmpId",params);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public Department selectClassByApplyCode(String applyCode) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            return sqlSession.selectOne(namespace + ".selectClassByApplyCode",applyCode);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int insertEmpAndDept(JSONObject params) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert(namespace + ".insertEmpAndDept",params);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
    }

    public Map selectRecoverJoin(JSONObject result){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Map map = sqlSession.selectMap(namespace + ".selectRecoverJoin",result,"id");
            return map;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /*离开班级*/
    public int delteEmpAndDept(JSONObject params){
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.delete(namespace + ".delteEmpAndDept",params);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

}
