package com.project.dao.organization.mapper;

import com.project.entity.organization.Employee;
import org.apache.ibatis.annotations.Select;

public interface EmployeeMapper {

    @Select("select * from employee where uuid = #{uuid}")
    public Employee selectAnEmployeeByUUId(String uuid);

//    @Select("select * from employee where email = #{email}")
//    public Employee selectAnEmployeeByEmail(String email);

}
