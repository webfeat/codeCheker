package com.project.dao.permission.permissionImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.permission.ModuleDao;
import com.project.entity.permission.Module;
import com.project.entity.permission.Permission;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;

@Repository
public class ModuleDaoBean extends AppDao implements ModuleDao {

    private static final String nameSpace = "com.project.entity.permission.Module";

    public HashMap findModules(Object obj) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List moduels = sqlSession.selectList("com.project.entity.permission.Module.findModules",obj);
            HashMap hashMap = new HashMap();
            hashMap.put("data",moduels);
            sqlSession.close();
            return hashMap;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }


    public Module findModuleById(String moduleId) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Module module = sqlSession.selectOne("com.project.entity.permission.Module.findModuleById",moduleId);
            sqlSession.close();
            return module;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int findModuleCodeMax() {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Integer integer = sqlSession.selectOne("com.project.entity.permission.Module.findModuleCodeMax");
            sqlSession.close();
            return integer;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public int saveModule(Module module){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int result = sqlSession.insert("com.project.entity.permission.Module.saveModule",module);
            sqlSession.commit();
            sqlSession.close();
            return result;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public List<Module> findModulesByParentModuleId(int parentModuleId,int operatorId) {
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Module module = new Module();
            module.setParentModuleId(parentModuleId);
            JSONObject params = new JSONObject();
            params.put("parentModuleId",parentModuleId);
            params.put("operatorId",operatorId);
            List<Module> list = sqlSession.selectList("com.project.entity.permission.Module.findModulesByParentModuleId",params);
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Module> findModuleList(JSONObject jsonObject) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<Module>  list = sqlSession.selectList(nameSpace + ".findModuleList",jsonObject);
            sqlSession.close();
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    /*模糊查询*/
    public List<Permission> selectModulesByName(JSONObject params){
        try {
            SqlSession sqlSession = this.sqlFactoryUtil.openSession();
            List<Permission> list = sqlSession.selectList(nameSpace + ".selectModulesByName",params);
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /*通过权限点ID查找*/
      /*模糊查询*/
    public Module selectModulesByPermissionId(JSONObject params){
        try {
            SqlSession sqlSession = this.sqlFactoryUtil.openSession();
            Module module = sqlSession.selectOne(nameSpace + ".selectModulesByPermissionId",params);
            return module;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public int updateAModule(Module module) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.update(nameSpace + ".updateAModule",module);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public int deleteAModule(Module module) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.delete(nameSpace + ".deleteAModule",module);
            sqlSession.commit();
            sqlSession.close();
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }
}
