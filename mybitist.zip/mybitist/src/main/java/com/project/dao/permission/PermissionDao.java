package com.project.dao.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.Entity;
import com.project.entity.permission.Permission;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PermissionDao {
    public abstract int savePermission(Permission permission,JSONObject params);

    public abstract int updatePermission(Permission permission,JSONObject params);

    public abstract int deletePermission(int permissionId);

    public abstract Permission findPermissionById(int permissionId);
    public Permission findPermissionByCode(String code);

    public abstract List<Permission> findPermissions(JSONObject jsonObject);

    public List<Permission> selectByRoleId(int roleId);
    public List<Permission> noSelectedByRoleId(String[] ids);

    public int distributePermission(String newPermissions,int roleId);

}
