package com.project.dao.view;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.entity.MessageView;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by samsung on 2018/6/4.
 */
@Repository
public class VIewDaoBean extends AppDao implements ViewDao {
    public List<MessageView> findMessageMap(JSONObject params) {
        try {
            SqlSession sqlSession  = sqlFactoryUtil.openSession();
            List<MessageView> list = sqlSession.selectList("view.findMessageMap",params);
            return list;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
