package com.project.dao.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.OperatorConfig;
import com.project.entity.organization.Department;
import com.project.entity.permission.Operator;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public interface OperatorDao {

    public abstract Operator saveOperator(Operator operator) throws Exception;

    public abstract Operator findOperatorByUserName (String username) throws Exception;

    public Operator validateOperator(JSONObject jsonObject) throws  Exception;

    public List<Operator> findOperatorList(JSONObject params);

    public abstract Operator updateOperator(Operator operator);

    public Operator findOperatorByEmployeeId(int empId);

    public List<OperatorConfig> findAllConfigByDeptId(Department department);

    public List<Operator> findOperatorByEmployeeIds(JSONObject params);
}
