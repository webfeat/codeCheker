package com.project.dao.message.messageImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.message.PersonalMessageDao;
import com.project.entity.message.Attachment;
import com.project.entity.message.PersonMessage;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import sun.applet.Main;

import java.util.List;

/**
 * Created by samsung on 2018/5/10.
 */
@Repository
public class PersonalMessageDaoBean extends AppDao implements PersonalMessageDao{

    private static final String nameSpace = "com.project.dao.message.mapper.MessageMapper";
    //插入发布的作业
    public int InsertWorkMessage(PersonMessage personMessage){
        try {
            int count = this.inseartEntity(nameSpace + ".insertNewPersonMessage",personMessage);
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    public int insertAttachment(Attachment attachment){
        try {
            int count = this.inseartEntity(nameSpace + ".insertAttachment",attachment);
            return count;
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }

    /*根据班级ID查找出发送消息的人*/
    public String findAllSendEmpsEmails(JSONObject jsonObject){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            String emails = sqlSession.selectOne(nameSpace+".searchAllEmail",jsonObject);
           sqlSession.close();
            return emails;
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    public List<Attachment> findAllAttachement(JSONObject jsonObject){
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            List<Attachment> attachments = sqlSession.selectList(nameSpace + ".findAttachementByCode",jsonObject);
            sqlSession.close();
            return attachments;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
