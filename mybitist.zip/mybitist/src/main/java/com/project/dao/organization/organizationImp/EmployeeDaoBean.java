package com.project.dao.organization.organizationImp;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.AppDao;
import com.project.dao.organization.EmployeeDao;
import com.project.dao.organization.mapper.EmployeeMapper;
import com.project.entity.organization.Employee;
import com.project.util.SqlFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;


@Component
public class EmployeeDaoBean extends AppDao implements EmployeeDao{
    /*
    根据职员id查找一个职员
     */

    public Employee getEmployeeById(Integer employeeId){
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("employeeId",employeeId);
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Employee employee = sqlSession.selectOne("test.findUserById",jsonObject);
            sqlSession.close();
            return employee;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public Employee saveEmployee(Employee employee) {
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.insert("test.saveEmployee",employee);
            sqlSession.commit();

            if(count <= 0){
                return null;
            }

            Employee saved = sqlSession.selectOne("test.selectAnEmployeeByUUId",employee);
            sqlSession.close();
            return saved;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    //根据邮箱查找人员
    public Employee findAnEmployeeByEmail(String email){
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            Employee employee = sqlSession.selectOne("test.selectAnEmployeeByEmail",email);
            sqlSession.close();
            return employee;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    //根据邮箱查找人员
    public Employee updateEmployee(Employee employee){
        try{
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            int count = sqlSession.update("test.updateEmployee",employee);
            sqlSession.commit();
            sqlSession.close();
            return employee;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Employee> selectAllEmployeeByDept(JSONObject params) {
        try {
            SqlSession sqlSession = sqlFactoryUtil.openSession();
            return sqlSession.selectList("test.selectAllEmployeeByDept",params);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
