package com.project.dao.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.permission.Module;
import com.project.entity.permission.Permission;
import com.sun.org.apache.xpath.internal.operations.Mod;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

@Service
public interface ModuleDao {
    public abstract HashMap findModules(Object obj);

    public abstract Module findModuleById(String moduleId);

    //查找编码最大的模块
    public abstract int findModuleCodeMax();

    public abstract int saveModule(Module module);

    public abstract List<Module> findModulesByParentModuleId(int parentModuleId,int operatorId);

    public abstract List<Module> findModuleList(JSONObject jsonObject);

    public List<Permission> selectModulesByName(JSONObject params);

    public Module selectModulesByPermissionId(JSONObject params);

    public int updateAModule(Module module);

    public int deleteAModule(Module module);
}
