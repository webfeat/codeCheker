package com.project.dao.permission.mapper;

import com.project.entity.permission.Module;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ModuleMapper {

    //查找模块
    @Select("select * from module m where m.parentModuleId = #{parentModuleId}")
    public abstract List<Module> findModules(String parentModuleId);

}
