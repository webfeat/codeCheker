package com.project.controller;

import com.alibaba.fastjson.JSONObject;
import com.eaio.uuid.*;
import com.project.dao.message.AttachmentDao;
import com.project.dao.message.MessageDao;
import com.project.dao.message.PersonalMessageDao;
import com.project.dao.organization.DepartmentDao;
import com.project.dao.organization.EmployeeDao;
import com.project.entity.message.Attachment;
import com.project.entity.message.MessageWork;
import com.project.entity.organization.Department;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import com.project.service.organization.EmployeeService;
import com.project.util.EmailUtil;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.UUID;

/**
 * Created by samsung on 2018/5/10.
 */
@Controller
@RequestMapping("/fileuploado")
public class FileUploadTeacherController {

    @Resource
    DepartmentDao departmentDao;

    @Resource
    MessageDao messageDao;

    @Resource
    EmployeeDao employeeDao;

    @Resource
    EmployeeService employeeService;

    @Resource
    EmailUtil emailUtil;

    @Autowired
    private AttachmentDao attachmentDao;

    @Resource
    PersonalMessageDao personalMessageDao;

    // 上传文件存储目录
    private static final String UPLOAD_DIRECTORY = "E://upload//header//result";

    // 上传配置
    private static final int MEMORY_THRESHOLD = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE = 1024 * 1024 * 40; // 40MB
    private static final int MAX_REQUEST_SIZE = 1024 * 1024 * 50; // 50MB

    @RequestMapping(value = "/workUploadForTeacher",method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String workUploadForTeacher(HttpServletRequest request, HttpServletResponse response) throws IOException {

        // 检测是否为多媒体上传
        if (!ServletFileUpload.isMultipartContent(request)) {
            // 如果不是则停止
            PrintWriter writer = response.getWriter();
            writer.println("Error: 表单必须包含 enctype=multipart/form-data");
            writer.flush();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message","上传失败");
            jsonObject.put("status",false);
            return jsonObject.toJSONString();
        }

        // 配置上传参数
        DiskFileItemFactory factory = new DiskFileItemFactory();
        // 设置内存临界值 - 超过后将产生临时文件并存储于临时目录中
        factory.setSizeThreshold(MEMORY_THRESHOLD);

        // 设置临时存储目录
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

        ServletFileUpload upload = new ServletFileUpload(factory);

        // 设置最大文件上传值
        upload.setFileSizeMax(MAX_FILE_SIZE);

        // 设置最大请求值 (包含文件和表单数据)
        upload.setSizeMax(MAX_REQUEST_SIZE);

        // 中文处理
        upload.setHeaderEncoding("UTF-8");

        // 构造临时路径来存储上传的文件
        // 这个路径相对当前应用的目录
        //
        HttpSession httpSession = request.getSession();
        Operator operator = (Operator) httpSession.getAttribute("operator");
        String uploadPath = "";
        String attachementGroupId = UUID.randomUUID().toString();
        boolean hasFile = false;//判断是否有附件
        try {
            // 解析请求的内容提取文件数据
            List<FileItem> formItems = upload.parseRequest(request);
            Map<String,String> params = new HashMap<String, String>();
            if (formItems != null && formItems.size() > 0) {
                // 迭代表单数据
                for (FileItem item : formItems) {
                    // 处理不在表单中的字段
                    if (!item.isFormField()) {
                        //通过个人信息创建出路径
                        int deptId = Integer.parseInt(params.get("departmentId"));
                        Department department = departmentDao.getDepartmentById(deptId);
                        String deptCode = department.getDeptCode();
                        String orgName = department.getOrgName();
                        String type = "Teacher";
                        uploadPath = UPLOAD_DIRECTORY + "//" + orgName + "//" + deptCode + "//" + type;
                        /*接下来的工作是：文件读写,保存attachmentID*/

                        // 如果目录不存在则创建
                        File uploadDir = new File(uploadPath);
                        if (!uploadDir.exists()) {
                            uploadDir.mkdirs();
                        }

                        String fileName = new File(item.getName()).getName();
                        Attachment attachment = new Attachment();
                        com.eaio.uuid.UUID uuidO = new com.eaio.uuid.UUID();
                        attachment.setAttachmentId(uuidO.toString());
                        attachment.setAttachmentName(fileName);
                        attachment.setCreateDate(new Date());

                        attachmentDao.insertAttachment(attachment);
                        hasFile = true;

                        String filePath = uploadPath + File.separator + fileName;
                        File storeFile = new File(filePath);
                        // 在控制台输出文件的上传路径
                        System.out.println(filePath);
                        // 保存文件到硬盘
                        item.write(storeFile);
                        request.setAttribute("message",
                                "文件上传成功!");
                    }else{
                        String s2 = new String(item.getString().getBytes("ISO-8859-1"),"UTF-8");
                        params.put(item.getFieldName(),s2);
                    }
                }
            }

            String message = params.get("message");
            JSONObject msgObj = JSONObject.parseObject(message);
            MessageWork messageWork = new MessageWork();
            messageWork.setCreatorId(operator.getId());
            messageWork.setTitile(msgObj.getString("titile"));
            messageWork.setContent(String.valueOf(msgObj.get("content")));
            Date endTime = EmailUtil.dateFormateToDate(String.valueOf(msgObj.get("endTime")));
            messageWork.setEndTime(endTime);
            messageWork.setDepartmentId(Integer.parseInt(params.get("departmentId")));
            if(hasFile){
                messageWork.setAttachementCode(attachementGroupId);
            }
            messageWork.setUploadPath(uploadPath);
            messageWork.setResultPath(uploadPath.substring(UPLOAD_DIRECTORY.length(),uploadPath.length()) + File.separator + "student");
            messageWork.setStatus("进行中");
            messageWork.setType("publish");
            /*插入一条记录*/
            int count = messageDao.publishMessageWork(messageWork);
            JSONObject empP = new JSONObject();
            empP.put("departmentId",Integer.parseInt(params.get("departmentId")));
            //查找出邮箱，并且开始发送消息
            List<Employee> list = employeeDao.selectAllEmployeeByDept(empP);

            String toEmails = "";
            Department department = new Department();
            department.setId(Integer.parseInt(empP.getString("departmentId")));
            toEmails = employeeService.getToAddress(department,"publish");

            if(count > 0 && toEmails != null &&!"".equals(toEmails)){//保存成功后，开始发送群消息
                emailUtil.sendMessageEmail(toEmails,"作业发布消息",operator.getEmployee().getName() + "发布了一次作业，请注意按时完成");
            }

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message","上传成功");
            jsonObject.put("status",true);
        } catch (Exception ex) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message","上传失败");
            jsonObject.put("status",false);
            request.setAttribute("message",
                    "错误信息: " + ex.getMessage());
            ex.printStackTrace();
            return jsonObject.toJSONString();
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("message","上传失败");
        jsonObject.put("status",false);
        return jsonObject.toJSONString();
    }


    @RequestMapping(value = "/downloadFileByAttachementCode")
    @ResponseBody
    public String downPhotoByStudentId(HttpServletRequest request,HttpServletResponse response){
       try {
            String attachementCode = request.getParameter("attachementCode");
            JSONObject params = new JSONObject();
            params.put("attachmentCode",attachementCode);
            List<Attachment> result = personalMessageDao.findAllAttachement(params);
            JSONObject resultOb = new JSONObject();
            resultOb.put("data",result);
            resultOb.put("status",true);
            resultOb.put("message","查询成功");
            return resultOb.toJSONString();
       }catch (Exception e){
           e.printStackTrace();
           JSONObject resultOb = new JSONObject();
           resultOb.put("data",new ArrayList<Attachment>());
           resultOb.put("status",false);
           resultOb.put("message","查询失败");
           return resultOb.toJSONString();
       }
    }

}
