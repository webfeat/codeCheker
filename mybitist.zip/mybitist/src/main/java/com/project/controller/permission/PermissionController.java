package com.project.controller.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.permission.ModuleDao;
import com.project.dao.permission.PermissionDao;
import com.project.entity.permission.Module;
import com.project.entity.permission.Permission;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

/**
 * Created by samsung on 2018/5/5.
 */
@Controller
@RequestMapping(value = "/permission")
public class PermissionController {

    @Resource
    PermissionDao permissionDao;

    @Resource
    ModuleDao moduleDao;

    @RequestMapping(value = "/findPermissionList",method = RequestMethod.GET , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findPermissionList(HttpServletRequest request){
        String currentPage = request.getParameter("currentPage");
        String pageNo = request.getParameter("pageNo");
        JSONObject paramsJson = new JSONObject();

        paramsJson.put("currentPage",Integer.parseInt(pageNo) * (Integer.parseInt(currentPage) - 1));
        paramsJson.put("pageNo",Integer.parseInt(pageNo));

        //查询
        List<Permission> list = permissionDao.findPermissions(paramsJson);
        List<Permission> allList = permissionDao.findPermissions(new JSONObject());
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("pageSize",Math.ceil(allList.size()/Integer.valueOf(String.valueOf(paramsJson.get("pageNo")))));
        jsonObject.put("totalItems",allList.size());
        jsonObject.put("status",200);
        jsonObject.put("data",list);
        jsonObject.put("message","成功");

        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/insertPermission",method = RequestMethod.POST , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String insertPermission(HttpServletRequest request){
        String name = request.getParameter("name");
        String code = request.getParameter("code");
        String moduleId = request.getParameter("moduleId");
        Permission permission = new Permission();
        permission.setCode(code);
        permission.setName(name);
        permission.setCreateDate(new Date());

        JSONObject params = new JSONObject();
        params.put("createDate",new Date());
        params.put("moduleId",moduleId);

        int count = permissionDao.savePermission(permission,params);
        JSONObject jsonObject = new JSONObject();
        if(count < 1){
            jsonObject.put("status",false);
            jsonObject.put("code",501);
            jsonObject.put("message","添加失败");
        }else{
            jsonObject.put("status",true);
            jsonObject.put("code",200);
            jsonObject.put("message","添加成功");
        }
        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/deletePermission",method = RequestMethod.POST , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String deletePermission(HttpServletRequest request){
        String permissionIdStr = request.getParameter("permissionId");
        int permissionId = Integer.parseInt(permissionIdStr);
        int count = permissionDao.deletePermission(permissionId);
        JSONObject jsonObject = new JSONObject();
        if(count < 1){
            jsonObject.put("status",false);
            jsonObject.put("code",501);
            jsonObject.put("message","删除失败");
        }else{
            jsonObject.put("status",true);
            jsonObject.put("code",200);
            jsonObject.put("message","删除成功");
        }
        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/updatePermission",method = RequestMethod.POST , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String updatePermission(HttpServletRequest request){
        String permissionIdStr = request.getParameter("permissionId");
        int permissionId = Integer.parseInt(permissionIdStr);
        String name = request.getParameter("name");
        String code = request.getParameter("code");
        String moduleId = request.getParameter("moduleId");

        Module module = this.moduleDao.findModuleById(moduleId);

        Permission permission = permissionDao.findPermissionById(permissionId);
        permission.setName(name);
        permission.setCode(code);
        permission.setUpdateDate(new Date());

        JSONObject params = new JSONObject();
        params.put("permissionId",permissionId);
        params.put("updateDate",new Date());
        params.put("moduleId",Integer.parseInt(moduleId));

        int count = permissionDao.updatePermission(permission,params);

        JSONObject jsonObject = new JSONObject();
        if(count < 1){
            jsonObject.put("status",false);
            jsonObject.put("code",501);
            jsonObject.put("message","删除失败");
        }else{
            jsonObject.put("status",true);
            jsonObject.put("code",200);
            jsonObject.put("message","删除成功");
        }
        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/findPermission",method = RequestMethod.GET , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findPermissionById(HttpServletRequest request){
        String permissionIdStr = request.getParameter("permissionId");
        int permissionId = Integer.parseInt(permissionIdStr);
        Permission permission = permissionDao.findPermissionById(permissionId);
        JSONObject parmas = new JSONObject();
        parmas.put("permissionId",permissionId);
        Module module = moduleDao.selectModulesByPermissionId(parmas);
        JSONObject jsonObject = new JSONObject();
        if(permission != null){
            jsonObject.put("status",true);
            jsonObject.put("data",permission);
            jsonObject.put("module",module);
            jsonObject.put("message","查询成功");
        }else{
            jsonObject.put("status",false);
            jsonObject.put("data",null);
            jsonObject.put("message","查询失败");
        }
        return jsonObject.toJSONString();
    }

    /*权限分配查看已分配权限*/
    @RequestMapping(value = "/findDisPermission",method = RequestMethod.GET , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findDisPermission(HttpServletRequest request){
        String roleIdStr = request.getParameter("roleId");
        int roleId = Integer.parseInt(roleIdStr);
        List<Permission> permissions = permissionDao.selectByRoleId(roleId);
        String ids = "";

        for(int i = 0 ; i < permissions.size();i++){
            int tempId = permissions.get(i).getId();
            ids += tempId + ",";
        }

        //如果分配权限
        if(!"".equals(ids)){
            ids = ids.substring(0,ids.length()-1);
        }else{
            ids = "-1";
        }

        List<Permission> disPermisson = permissionDao.noSelectedByRoleId(ids.split(","));

        JSONObject jsonObject = new JSONObject();
        if(permissions != null){
            jsonObject.put("status",true);
            jsonObject.put("permissions",permissions);
            jsonObject.put("disPermisson",disPermisson);
            jsonObject.put("message","删除成功");
        }else{
            jsonObject.put("status",false);
            jsonObject.put("data",null);
            jsonObject.put("message","删除失败");
        }
        return jsonObject.toJSONString();
    }

    /*权限分配存储操作*/
    @RequestMapping(value = "/distributePermission",method = RequestMethod.POST , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String distributePermission(HttpServletRequest request){
        String idsStr = request.getParameter("permissionIds");
        String roleIdStr = request.getParameter("roleId");
        int roleId = Integer.parseInt(roleIdStr);
        int count = permissionDao.distributePermission(idsStr,roleId);

        JSONObject jsonObject = new JSONObject();
        if(count >= 0){
            jsonObject.put("status",true);
            jsonObject.put("code",200);
            jsonObject.put("message","删除成功");
        }else{
            jsonObject.put("status",false);
            jsonObject.put("code",501);
            jsonObject.put("message","删除失败");
        }
        return jsonObject.toJSONString();
    }

    /**/
     /*权限查询操作*/
    @RequestMapping(value = "/selectPermissionByName",method = RequestMethod.POST , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String selectPermissionByName(HttpServletRequest request){
        String name = request.getParameter("name");
        String moduleId = request.getParameter("moduleId");
        if(name == null){
            name = "";
        }
        JSONObject params = new JSONObject();
        params.put("name",name);
        if(moduleId != null){
            params.put("moduleId",Integer.parseInt(moduleId));
        }

        List<Permission> list = moduleDao.selectModulesByName(params);

        JSONObject jsonObject = new JSONObject();
        if(list != null && list.size() >= 0){
            jsonObject.put("status",true);
            jsonObject.put("data",list);
            jsonObject.put("message","查询成功");
        }else{
            jsonObject.put("status",false);
            jsonObject.put("data",null);
            jsonObject.put("message","查询失败");
        }
        return jsonObject.toJSONString();
    }
}
