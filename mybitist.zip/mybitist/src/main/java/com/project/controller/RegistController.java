package com.project.controller;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.util.IOUtils;
import com.project.entity.message.Message;
import com.project.service.message.MessageService;
import com.project.service.organization.EmployeeService;
import com.project.util.EmailUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.InputStreamReader;

@Controller
@RequestMapping("/regist")
public class RegistController {

    @Autowired
    EmailUtil emailUtil;

    @Autowired
    MessageService messageService;

    @Autowired
    EmployeeService employeeService;

    @RequestMapping("/sendEmailText")
    public void sendEmailText(HttpServletRequest request){
        System.out.println(request);
    }

    @RequestMapping(value = "/registPerson",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String registForStudent(HttpServletRequest request){
        try {
            //从regust里面获取数据
            BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream()));
            String body = IOUtils.readAll(reader);
            JSONObject jsonObject = JSONObject.parseObject(body);

            //传入service做处理
            JSONObject resultObj = employeeService.registPerson(jsonObject);
            return resultObj.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
        }
        return "";
    }

    @RequestMapping(value = "/getAuthCode",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String getAuthCode(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        try{
            //获取邮箱
            String email = request.getParameter("email");
            Message message = messageService.sendRegistCodeMessage(email);
            if(message == null){//如果发送失败，直接在后台抛出异常，帮助前端提醒
                jsonObject.put("status","失败");
                jsonObject.put("code",500);
                jsonObject.put("message","信息发送失败");
            }else{
                jsonObject.put("status","成功");
                jsonObject.put("code",200);
                jsonObject.put("message","信息发送成功");
            }
        }catch (Exception e){
            e.printStackTrace();
            return jsonObject.toJSONString();
        }
        return jsonObject.toJSONString();
    }


}
