package com.project.controller.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.permission.OperaotorConfigDao;
import com.project.dao.permission.OperatorDao;
import com.project.entity.OperatorConfig;
import com.project.entity.permission.Operator;
import com.project.service.permission.OperatorService;
import com.project.util.Aes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

/**
 * Created by samsung on 2018/5/5.
 */
@Controller
public class OperatorController {

    @Autowired
    OperatorService operatorService;

    @Resource
    OperatorDao operatorDao;

    @Resource
    OperaotorConfigDao operaotorConfigDao;

    @RequestMapping(value = "/operator/optList",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findOperatorList(HttpServletRequest request){

        String currentPage = request.getParameter("currentPage");
        String pageNo = request.getParameter("pageNo");
        JSONObject paramsJson = new JSONObject();
        paramsJson.put("currentPage",Integer.parseInt(currentPage) - 1);
        paramsJson.put("pageNo",Integer.parseInt(pageNo));

        List<Operator> list = operatorDao.findOperatorList(paramsJson);
        List<Operator> allList = operatorDao.findOperatorList(new JSONObject());

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("pageSize",Math.ceil(allList.size()/Integer.valueOf(String.valueOf(paramsJson.get("pageNo")))));
        jsonObject.put("totalItems",allList.size());
        jsonObject.put("status",200);
        jsonObject.put("data",list);
        jsonObject.put("message","成功");

        return jsonObject.toJSONString();
    }


    /*查询operatorConfig*/
    @RequestMapping(value = "/operator/findOperatorConfigByOperatorId",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findOperatorConfigByOperatorId(HttpServletRequest request){
        String deptIdStr = request.getParameter("departmentId");
        int departmentId = Integer.valueOf(deptIdStr);

        Operator operator = (Operator) request.getSession().getAttribute("operator");
        int id = operator.getId();
        OperatorConfig operatorConfig = operaotorConfigDao.findOperatorConfigByOperatorId(id,departmentId);
        if(operatorConfig == null){
            OperatorConfig newConfig = new OperatorConfig();
            newConfig.setMessageConfig("{\"workBublish\":true,\"message\":true,\"empChange\":true,\"workEnd\":true}");
            newConfig.setCreateDate(new Date());
            newConfig.setDepartmentId(departmentId);
            newConfig.setOperatorId(operator.getId());
            int count = operaotorConfigDao.insertOperatorConfig(newConfig);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("data",newConfig);
            jsonObject.put("status",true);
            jsonObject.put("message","查询成功");
            return jsonObject.toJSONString();
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data",operatorConfig);
        jsonObject.put("status",true);
        jsonObject.put("message","查询成功");

        return jsonObject.toJSONString();
    }

    /*查询operatorConfig*/
    @RequestMapping(value = "/operator/updateOperatorConfig",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String updateOperatorConfig(HttpServletRequest request){
        JSONObject resultObj = new JSONObject();
        String messageConfig = request.getParameter("messageConfig");
        String departmentId = request.getParameter("departmentId");

        //获取登录的操作员
        Operator operator = (Operator) request.getSession().getAttribute("operator");
        int id = operator.getId();

        //查询出本身操作员的消息配置参数
        OperatorConfig operatorConfig = operaotorConfigDao.findOperatorConfigByOperatorId(id,Integer.valueOf(departmentId));
        operatorConfig.setMessageConfig(messageConfig);

        //更新配置的函数
        int count = operaotorConfigDao.updateOperatorConfig(operatorConfig);

        if(count < 1){
            resultObj.put("status",false);
            resultObj.put("code",501);
            resultObj.put("message","查找失败");
        }else{
            resultObj.put("status",true);
            resultObj.put("code",200);
            resultObj.put("message","查找成功");
        }
        return resultObj.toJSONString();
    }


    /*更新账户密码*/
    @RequestMapping(value = "/operator/updateOperator",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String updateOperator(HttpServletRequest request){
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String newPassword = request.getParameter("newPassword");

        Operator operator = (Operator)request.getSession().getAttribute("operator");
        if(operator == null){
            JSONObject error = new JSONObject();
            error.put("code",503);
            error.put("status",true);
            error.put("message","未登录");
        }else if(password != null && !password.equals(confirmPassword)){
            JSONObject error = new JSONObject();
            error.put("code",501);
            error.put("status",true);
            error.put("message","密码不一致");
        }else if(confirmPassword != null && !confirmPassword.equals(password)){
            JSONObject error = new JSONObject();
            error.put("code",501);
            error.put("status",true);
            error.put("message","密码不一致");
        }else if(confirmPassword == null || password == null){
            JSONObject error = new JSONObject();
            error.put("code",501);
            error.put("status",true);
            error.put("message","密码不能为空");
        }

        JSONObject params = new JSONObject();
        params.put("userName",operator.getUsername());
        params.put("password",password);

        String userName = operator.getUsername();
        Operator validateOperator = operatorService.validateOperator(params);
        if(validateOperator == null){
            JSONObject error = new JSONObject();
            error.put("code",501);
            error.put("status",true);
            error.put("message","密码错误");
            return error.toJSONString();
        }

        newPassword = Aes.aesEncrypt(newPassword);
        validateOperator.setPassword(newPassword);
        operatorDao.updateOperator(validateOperator);

        JSONObject result = new JSONObject();
        result.put("status",true);
        result.put("data",validateOperator);
        result.put("message","成功");

        return result.toJSONString();
    }
}
