package com.project.controller;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.organization.EmployeeDao;
import com.project.dao.permission.OperatorDao;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import com.project.entity.permission.Role;
import com.project.service.permission.OperatorService;
import com.project.service.permission.RoleService;
import com.project.util.AuthenUtil;
import com.project.util.JPlagApi;
import com.project.util.RequestUtil;
import com.project.util.TestMain;
import jplag.JPlag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/Login")
public class LoginController {

    @Autowired
    RequestUtil requestUtil;

    @Autowired
    OperatorService operatorService;

    @Autowired
    RoleService roleService;

    @Autowired
    EmployeeDao employeeDao;

    @Autowired
    AuthenUtil authenUtil;

    @Autowired
    JPlagApi jPlagApi;
    /**
     * 学生登陆
     */
    @RequestMapping(value = "/studentLogin",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String studentLogin(HttpServletRequest request, HttpSession session){

        System.out.println("登陆的sessionId"+session.getId());
        JSONObject jsonObject = new JSONObject();
        String userName = request.getParameter("userName");
        String password = request.getParameter("password");

        jsonObject.put("userName",userName);
        jsonObject.put("password",password);
        try {
           Operator operator = operatorService.validateOperator(jsonObject);

           if(operator != null){
               Role role = roleService.findRoleByOperatorId(operator.getId());
               session.setAttribute("operator",operator);
               Employee employee = operator.getEmployee();
               employee = employeeDao.getEmployeeById(employee.getId());
               String uuid = employee.getUuid();
               session.setAttribute("uuid",uuid);
               session.setAttribute("employee",employee);
               session.setAttribute("org",employee.getOrganization());

               //登陆成功之后向前端添加一些标识
               JSONObject result = new JSONObject();
               result.put("status",true);
               result.put("message","登录成功");
               result.put("code",true);

               //存储返回的数据
               JSONObject returnData = new JSONObject();
               returnData.put("uuid",uuid);
               returnData.put("userName",operator.getUsername());
               returnData.put("employee",employee);
               returnData.put("role",role);
               result.put("data",returnData);
                return  result.toJSONString();
           }else{
                JSONObject loginFilred = new JSONObject();
                loginFilred.put("status",false);
                loginFilred.put("message","密码或用户名输入错误！");
                loginFilred.put("code",200);
                return loginFilred.toJSONString();
           }
        }catch (Exception e){
            e.printStackTrace();
        }
        return  jsonObject.toJSONString();
    }

    @RequestMapping(value = "/loginOut",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String loginOut(HttpServletRequest httpServletRequest){
        try {
            httpServletRequest.getSession().removeAttribute("operator");
            httpServletRequest.getSession().removeAttribute("uuid");
            return "成功";
        }catch (Exception e){
            e.printStackTrace();
            return "成功";
        }
    }

}
