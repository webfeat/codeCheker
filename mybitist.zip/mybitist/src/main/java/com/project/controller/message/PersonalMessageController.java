package com.project.controller.message;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.message.MessageDao;
import com.project.dao.organization.DepartmentDao;
import com.project.dao.permission.OperatorDao;
import com.project.dao.view.ViewDao;
import com.project.entity.message.MessageWork;
import com.project.entity.organization.Department;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import com.project.service.message.MessageService;
import com.project.service.message.PersonalMessageService;
import com.project.util.JPlagApi;
import com.project.util.RequestUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by samsung on 2018/5/10.
 */
@Controller
@RequestMapping(value = "/message")
public class PersonalMessageController {

    @Resource
    private PersonalMessageService personalMessageService;

    @Resource
    private DepartmentDao departmentDao;

    @Resource
    private OperatorDao operatorDao;

    @Resource
    MessageDao messageDao;

    @Resource
    JPlagApi jPlagApi;

    @Resource
    RequestUtil requestUtil;

    @Resource
    MessageService messageService;

    static final String UploadDir = "E:\\upload\\header\\result";

    /*老师发布作业，在文件发送成功后再发送消息*/
    public String publishWorkForTeacher(HttpServletRequest request){
        try {
            String message = request.getParameter("message");
            JSONObject jsonObject = new JSONObject();
            jsonObject = JSONObject.parseObject(message);
            Operator operator = (Operator)request.getSession().getAttribute("operator");
            Employee employee = operator.getEmployee();
            Department department = employee.getDepartment();

            JSONObject result = personalMessageService.insertNewPersonalMessage(jsonObject,operator,department);
            return result.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    /*获取所有的发布记录*/
    @RequestMapping(value = "/findAllMessageList",method = RequestMethod.GET,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findAllMessageList(HttpServletRequest request){
        try {
            String currentPage = request.getParameter("currentPage");//通过传入变化后页面
            String pageSize = request.getParameter("pageSize");//一页多少条
            String departmentId = request.getParameter("departmentId");//一页多少条
            JSONObject params = new JSONObject();
            params.put("currentPage",currentPage);
            params.put("pageSize",pageSize);
            params.put("type","publish");
            params.put("departmentId",departmentId);

            Operator operator = (Operator) request.getSession().getAttribute("operator");
            JSONObject jsonObject = personalMessageService.selectAllMessages(params,operator);
            return jsonObject.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    /*学生获取所有的发布记录，先查出班级的老师，然后再查询记录*/
    @RequestMapping(value = "/findAllMessageListStu",method = RequestMethod.GET,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findAllMessageListStu(HttpServletRequest request){
        try {
            String currentPage = request.getParameter("currentPage");//通过传入变化后页面
            String pageSize = request.getParameter("pageSize");//一页多少条
            String departmentId = request.getParameter("departmentId");//一页多少条
            JSONObject params = new JSONObject();
            params.put("currentPage",currentPage);
            params.put("pageSize",pageSize);
            params.put("type","publish");
            params.put("departmentId",departmentId);
            Operator operator = (Operator) request.getSession().getAttribute("operator");
            if(operator == null){
                JSONObject error = new JSONObject();
                error.put("status",false);
                error.put("message","登录过期");
                error.put("code",503);
            }else {
                params.put("currentOpt",operator.getId());
            }
            Department department = departmentDao.getDepartmentById(Integer.parseInt(departmentId));

            int teacherEmpId = department.getEmployeeId();
            Operator teacher = operatorDao.findOperatorByEmployeeId(teacherEmpId);
            JSONObject jsonObject = personalMessageService.selectAllMessages(params,teacher);
            return jsonObject.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }


    /*生成报告*/
    @RequestMapping(value = "generateResult",method = RequestMethod.GET,produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String generateResult(HttpServletRequest request){
        try {
            String messageId = request.getParameter("messageId");
            int msgId = Integer.parseInt(messageId);
            JSONObject params = new JSONObject();
            params.put("messageId",msgId);

            MessageWork messageWork = messageDao.findMessageWorkById(params);

            String path = messageWork.getResultPath();
            System.out.println(path);
            String[] strs = path.split("//");
            String temp = "";
            for (int i = 0 ; i < strs.length ;i++){
                temp += strs[i]+"\\\\";
            }
            temp +=  msgId;

            File uploadDir = new File(UploadDir + temp);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
                JSONObject message = new JSONObject();
                message.put("status",false);
                message.put("code",200);
                message.put("message","提交文件个数为0");
                return message.toJSONString();
            }
            File[] files = uploadDir.listFiles();
            if(files.length < 2){
                JSONObject message = new JSONObject();
                message.put("status",false);
                message.put("code",200);
                message.put("message","提交文件个数不足");
                return message.toJSONString();
            }
            jPlagApi.run(UploadDir +temp,UploadDir+temp);
            System.out.println(temp);
            JSONObject result = new JSONObject();
            result.put("status",true);
            result.put("code",200);
            result.put("message","成功");
            return result.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("status",false);
            error.put("code",500);
            error.put("message","失败");
            return error.toJSONString();
        }
    }

    @RequestMapping(value = "deleteMessageWork",method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String deleteMessageWork(HttpServletRequest request){
        try {
            String messageId = request.getParameter("messageId");
            if(messageId == null){
                JSONObject error = new JSONObject();
                error.put("status",false);
                error.put("code",503);
                error.put("message","操作异常");
                return error.toJSONString();
            }
            JSONObject params = new JSONObject();
            int msgId = Integer.parseInt(messageId);
            params.put("messageId",msgId);

            MessageWork messageWork = messageDao.findMessageWorkById(params);
            messageWork.setType("delete");
            int count = messageDao.updateMessageWork(messageWork);
            if(count > 0){
                JSONObject result = new JSONObject();
                result.put("status",true);
                result.put("code",200);
                result.put("message","删除成功");
                return result.toJSONString();
            }else{
                JSONObject error = new JSONObject();
                error.put("status",false);
                error.put("code",503);
                error.put("message","操作异常");
                return error.toJSONString();
            }
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("status",false);
            error.put("code",503);
            error.put("message","操作异常");
            return error.toJSONString();
        }
    }

    @RequestMapping(value = "findMessageByMessageId",method = RequestMethod.GET,produces = "application/json;charset=utf-8")
    @ResponseBody
    public String findMessageByMessageId(HttpServletRequest request){
        try {
            String messageId = request.getParameter("messageId");
            int msgId = Integer.parseInt(messageId);
            JSONObject params = new JSONObject();
            params.put("messageId",msgId);
            MessageWork messageWork = messageDao.findMessageWorkById(params);

            JSONObject result = new JSONObject();
            result.put("status",true);
            result.put("message","成功");
            result.put("data",messageWork);
            return result.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            JSONObject result = new JSONObject();
            result.put("status",false);
            result.put("message","失败");
            result.put("code",500);
            return result.toJSONString();
        }
    }

    /*无附件上传时*/
    @RequestMapping(value = "saveMessageWork",method = RequestMethod.POST,produces = "application/json;charset=utf-8")
    @ResponseBody
    public String saveMessageWork(HttpServletRequest request){
        try {
            Operator operator = (Operator)request.getSession().getAttribute("operator");

            //实例化一个对象
            JSONObject params = requestUtil.getParamsFromRequirest(request);
            MessageWork messageWork = new MessageWork();
            messageWork.setContent(params.getString("content"));
            messageWork.setTitile(params.getString("titile"));
            messageWork.setType(params.getString("publish"));
            messageWork.setType("publish");
//            Date endTime = EmailUtil.dateFormateToDate(String.valueOf(params.get("endTime")));
            Date endTime = new Date(String.valueOf(params.get("endTime")));
            messageWork.setEndTime(endTime);

            //生成Jplag扫描路径
            int departmentId = params.getInteger("departmentId");
            Department department = departmentDao.getDepartmentById(departmentId);
            String orgName = department.getOrgName();
            String orgCode = department.getDeptCode();
            String type = "Teacher";
            String uploadPath = UploadDir + "\\" + orgName + "\\" + orgCode + "\\" + type;
            String resultPath = uploadPath + "\\" + "student";

            messageWork.setUploadPath(uploadPath);
            messageWork.setResultPath(resultPath);
            messageWork.setDepartmentId(departmentId);
            messageWork.setCreatorId(operator.getId());
            messageWork.setStatus("进行中");

            //进行保存
            int count = messageDao.publishMessageWork(messageWork);
            JSONObject jsonObject = new JSONObject();
            if(count > 0){
                jsonObject.put("message","发布成功");
                jsonObject.put("status",true);
            }else {
                jsonObject.put("message","发布失败");
                jsonObject.put("status",false);
            }
            return jsonObject.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("message","发布失败");
            error.put("status",false);
            return error.toJSONString();
        }
    }

    /*获取首页的消息列表*/
    @RequestMapping(value = "selectMessageForWelcome",method = RequestMethod.GET,produces = "application/json;charset=utf-8")
    @ResponseBody
    public String selectMessageForWelcome(HttpServletRequest request){
        try {
            /*获取与他相关的消息*/
            Operator operator = (Operator)request.getSession().getAttribute("operator");
            if(operator == null){
                JSONObject error = new JSONObject();
                error.put("data",null);
                error.put("message","未登录");
                error.put("code",503);
                return error.toJSONString();
            }
            JSONObject params = new JSONObject();
            params.put("employeeId",operator.getEmployee().getId());
            List<Department> departments = departmentDao.findDepartmentList(params);
            int[] deptIds = null;
            if(departments != null && departments.size() > 0){
                deptIds = new int[departments.size()];
                for (int i = 0 ; i < departments.size() ;i++){
                    deptIds[i] = departments.get(i).getId();
                }
            }else{
                JSONObject result = new JSONObject();
                result.put("data",null);
                result.put("message","查找完成");
                result.put("code",200);
                return result.toJSONString();
            }
            JSONObject deptParams = new JSONObject();
            deptParams.put("departmentIds",deptIds);
            deptParams.put("currentPage",0);
            deptParams.put("pageNo",5);

            List<MessageWork> messageWorks = messageDao.selectMessageForWelcome(deptParams);
            JSONObject result = new JSONObject();
            result.put("data",messageWorks);
            result.put("message","查找完成");
            result.put("code",200);
            return result.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("status",false);
            error.put("message","查询失败");
            return error.toJSONString();
        }
    }

    @RequestMapping(value = "countForPipe",method = RequestMethod.GET,produces = "application/json;charset=utf-8")
    @ResponseBody
    public String countForPipe(HttpServletRequest request){
        try {
            Operator operator = (Operator) request.getSession().getAttribute("operator");
            if(operator == null){
                JSONObject error = new JSONObject();
                error.put("status",false);
                error.put("message","未登录");
                error.put("code",503);
                return error.toJSONString();
            }
            JSONObject params = new JSONObject();
            params.put("operatorId",operator.getId());
           List<MessageWork> works = messageDao.findCLearlyMessage(params);
           List<JSONObject> size = new ArrayList<JSONObject>();

           for (int i = 0 ; i < works.size() ;i++){
               JSONObject params_ = new JSONObject();
               params_.put("departmentId",works.get(i).getDepartmentId());
               params_.put("messageId",works.get(i).getId());
               JSONObject resultPipe =  messageDao.countPipe(params_);
               size.add(resultPipe);
           }

           JSONObject result = new JSONObject();
            result.put("data",size);
            result.put("code",200);
            result.put("message","查询完成");
            return result.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("status",false);
            error.put("message","查询失败");
            return error.toJSONString();
        }
    }

    /*查询所有已完成的消息id*/
    @RequestMapping(value = "selectFinished",method = RequestMethod.GET,produces = "application/json;charset=utf-8")
    @ResponseBody
    public String selectFinished(HttpServletRequest request){
        try {
            Operator operator = (Operator) request.getSession().getAttribute("operator");
            if(operator == null){
                JSONObject error = new JSONObject();
                error.put("status",false);
                error.put("message","未登录");
                error.put("code",503);
                return error.toJSONString();
            }
            JSONObject params = new JSONObject();
            params.put("operatorId",operator.getId());
            List<Integer> works = messageDao.selectFinished(params);

            JSONObject result = new JSONObject();
            result.put("data",works);
            result.put("code",200);
            result.put("message","查询完成");
            return result.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("status",false);
            error.put("message","查询失败");
            return error.toJSONString();
        }
    }

    /*查询所有消息，公供表格使用*/
    @RequestMapping(value = "selectAllTypeMessages",method = RequestMethod.GET,produces = "application/json;charset=utf-8")
    @ResponseBody
    public String selectAllTypeMessages(HttpServletRequest request){
            Operator operator = (Operator) request.getSession().getAttribute("operator");
            if(operator == null){
                JSONObject error = new JSONObject();
                error.put("status",false);
                error.put("code",503);
                return error.toJSONString();
            }

        String currentPage = request.getParameter("currentPage");
        String pageNo = request.getParameter("pageNo");
        JSONObject paramsJson = new JSONObject();
        paramsJson.put("currentPage",(Integer.parseInt(currentPage) - 1) * Integer.parseInt(pageNo));
        paramsJson.put("pageNo",Integer.parseInt(pageNo));

        JSONObject result = messageService.findAllTypeMessage(operator,paramsJson);

        return result.toJSONString();
    }

    /*统计已交与未交，在结果详情中展示*/
    @RequestMapping(value = "countScoresSubmit",method = RequestMethod.GET,produces = "application/json;charset=utf-8")
    @ResponseBody
    public String countScoresSubmit(HttpServletRequest request){
            JSONObject params = requestUtil.getParamsFromRequirest(request);
            return messageService.countScoresSubmit(params).toJSONString();
    }


    /*统计已交与未交，在结果详情中展示*/
    @RequestMapping(value = "findSendMessageGrid",method = RequestMethod.GET,produces = "application/json;charset=utf-8")
    @ResponseBody
    public String findSendMessageGrid(HttpServletRequest request){
        try {
            JSONObject params = requestUtil.getParamsFromRequirest(request);

            String currentPage = request.getParameter("currentPage");
            String pageNo = request.getParameter("pageNo");
            params.put("currentPage",(Integer.parseInt(currentPage) - 1) * Integer.parseInt(pageNo));
            params.put("pageNo",Integer.parseInt(pageNo));

            Operator operator = (Operator) request.getSession().getAttribute("operator");

            int[] deptIds = new int[0];

            if(params.get("rType") == "t"){//教师
                params.put("operatorId",operator.getId());
            }else{//学生
                JSONObject deptParams = new JSONObject();
                deptParams.put("employeeId",operator.getEmployee().getId());
                List<Department> list = departmentDao.getDepartmentsJoined(deptParams);
                deptIds = new int[list.size()];
                for (int i = 0 ; i < deptIds.length ;i++) {
                    deptIds[i] = list.get(i).getId();
                }
                params.put("deptIds",deptIds);
            }

            List<MessageWork> list = messageDao.findSendMessageGrid(params);
            params.put("currentPage",null);
            params.put("pageNo",null);

            List<MessageWork> all = messageDao.findSendMessageGrid(params);

            JSONObject result = new JSONObject();
            result.put("total",all.size());
            result.put("data",list);
            result.put("message","成功");
            result.put("status",false);
            return result.toJSONString();
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("message","成功");
            error.put("status",false);
            return error.toJSONString();
        }
    }

}
