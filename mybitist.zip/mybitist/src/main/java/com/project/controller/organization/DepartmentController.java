package com.project.controller.organization;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.message.MessageDao;
import com.project.dao.organization.DepartmentDao;
import com.project.dao.organization.EmployeeDao;
import com.project.entity.message.Message;
import com.project.entity.organization.Department;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import com.project.service.message.MessageService;
import com.project.service.organization.DepartmentService;
import com.project.util.EmailUtil;
import com.project.util.RequestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/dept")
public class DepartmentController {

    @Autowired
    DepartmentDao departmentDao;

    @Autowired
    RequestUtil requestUtil;

    @Autowired
    DepartmentService departmentService;

    @Autowired
    EmployeeDao employeeDao;

    @Autowired
    EmailUtil emailUtil;

    @Autowired
    MessageDao messageDao;

    @RequestMapping(value = "/getDepartmentById", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String getDepartmentById(HttpServletRequest request) {
        String departmentId = request.getParameter("departmentId");
        Integer integer = Integer.parseInt(departmentId);
        Department department = departmentDao.getDepartmentById(integer);
        JSONObject result = new JSONObject();
        result.put("data", department);
        result.put("message", "查找成功");
        result.put("state", "200");

        return result.toJSONString();
    }

    @RequestMapping(value = "/findDepartmentList", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findDepartmentList(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String currentPage = request.getParameter("currentPage");
        String pageNo = request.getParameter("pageNo");
        Employee employee =(Employee)request.getSession().getAttribute("employee");
        Map<String, Object> map = request.getParameterMap();
        if (currentPage == null) {
            currentPage = "1";
        }
        if (pageNo == null) {
            pageNo = "10";
        }
        jsonObject.put("currentPage", Integer.valueOf(currentPage) - 1);
        jsonObject.put("pageNo", Integer.valueOf(pageNo));
        jsonObject.put("employeeId",employee.getId());

        JSONObject result = new JSONObject();
        result = departmentService.findDepartmentList(jsonObject);
        return result.toJSONString();

    }

    //新增班级
    @RequestMapping(value = "/insertNewDepartment", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String insertNewDepartment(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        JSONObject params = new JSONObject();

        String deptName = String.valueOf(request.getParameter("deptName"));
        String depPhoneNum = String.valueOf(request.getParameter("depPhoneNum"));
        String orgName = String.valueOf(request.getParameter("orgName"));//获取院校名称
        String orgCode = String.valueOf(request.getParameter("orgCode"));//获取院校编码

        params.put("deptName", deptName);
        params.put("depPhoneNum", depPhoneNum);
        params.put("orgName", orgName);
        params.put("orgCode", orgCode);

        HttpSession session = request.getSession();
        Operator operator = (Operator)session.getAttribute("operator");
        if(operator == null){
            jsonObject.put("status",false);
            jsonObject.put("message","未登录");
            jsonObject.put("code",503);
            return jsonObject.toJSONString();
        }
        Employee employee = operator.getEmployee();
        jsonObject = departmentService.insertNewDepartment(params, employee);
        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/deleteDepartmentById", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String deleteDepartmentById(HttpServletRequest request,HttpSession session){
        String departmentId = request.getParameter("deptId");
        Operator operator = (Operator)request.getSession().getAttribute("operator");
        System.out.println("deleteDepartmentById" + session.getId());

        if(session.getAttribute("operator") == null){
            JSONObject logined = new JSONObject();
            logined.put("status",503);
            logined.put("message","未登录");
            return logined.toJSONString();
        }
        JSONObject jsonObject = departmentService.deleteDepartmentById(Integer.parseInt(departmentId),operator.getId());
        return jsonObject.toJSONString();
    }

    /*通过邀请码加入班级*/
    @RequestMapping(value = "/joinDepartmentByApplyCode", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String joinDepartmentByApplyCode(HttpServletRequest request,HttpSession session){
        String applyCode = request.getParameter("applyCode");
        Operator operator = (Operator) session.getAttribute("operator");
        Employee employee = (Employee) session.getAttribute("employee");

        if(session.getAttribute("operator") == null){
            JSONObject logined = new JSONObject();
            logined.put("status",503);
            logined.put("message","未登录");
            return logined.toJSONString();
        }

        Department department = departmentDao.selectClassByApplyCode(applyCode);
        if(department == null){
            JSONObject temp = new JSONObject();
            temp.put("status",false);
            temp.put("message","为找到改班级");
            temp.put("code",200);
            return temp.toJSONString();
        }

        JSONObject paramsMap = new JSONObject();
        paramsMap.put("employeeId",employee.getId());
        paramsMap.put("departmentId",department.getId());
        Map searchMap = departmentDao.selectRecoverJoin(paramsMap);
        if(searchMap != null && searchMap.size() != 0){
            JSONObject temp = new JSONObject();
            temp.put("status",true);
            temp.put("message","已加入改班级");
            temp.put("code",200);
            return temp.toJSONString();
        }

        JSONObject params = new JSONObject();
        params.put("employeeId",employee.getId());
        params.put("departmentId",department.getId());

        int count = departmentDao.insertEmpAndDept(params);
        /*向教师发送消息*/
        int teacherId = department.getEmployeeId();
        Employee teacher = employeeDao.getEmployeeById(teacherId);
        String email = teacher.getEmail();

        Message message = new Message();
        message.setMessage(employee.getName() + ",加入了"+ department.getDeptName());
        message.setSetSubject("成员变动");
        message.setEmail(email);
        message.setCreatorId(operator.getId());
        message.setDepartmentId(department.getId());
        message.setType("personChange");
        messageDao.insertAMessage(message);
        boolean sucess = emailUtil.sendMessageEmail(email,"成员变动",employee.getName() + ",加入了您的班级");

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("status",sucess);
        jsonObject.put("message","成功");
        jsonObject.put("code",200);
        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/leaveClass", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String leaveClass(HttpServletRequest request){
        try {
            Operator operator = (Operator) request.getSession().getAttribute("operator");
            String deptId = request.getParameter("deptId");
            int empId = operator.getEmployee().getId();

            JSONObject params = new JSONObject();
            params.put("employeeId",empId);
            params.put("departmentId",Integer.parseInt(deptId));
            Department department = departmentDao.getDepartmentById(Integer.parseInt(deptId));

            Employee employee = operator.getEmployee();
            String email = employee.getEmail();
            Message message = new Message();
            message.setMessage(employee.getName() + ",离开" + department.getDeptName());
            message.setSetSubject("成员变动");
            message.setEmail(email);
            message.setCreatorId(operator.getId());
            message.setType("personChange");
            message.setDepartmentId(department.getId());
            messageDao.insertAMessage(message);
            boolean sucess = emailUtil.sendMessageEmail(email,"成员变动",employee.getName() + ",离开了" + department.getDeptName());

            int count = departmentDao.delteEmpAndDept(params);
            if(count <0 ){
                JSONObject error = new JSONObject();
                error.put("status",false);
                error.put("message","操作失败");
                return error.toJSONString();
            }else{
                //离开成功后发送消息
                JSONObject result  = new JSONObject();
                result.put("status",true);
                result.put("message","成功");
                return result.toJSONString();
            }
        }catch (Exception e){
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("status",false);
            error.put("message","操作失败");
            return error.toJSONString();
        }
    }
}
