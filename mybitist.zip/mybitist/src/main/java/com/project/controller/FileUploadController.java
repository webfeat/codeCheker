package com.project.controller;

import com.alibaba.fastjson.JSONObject;
import com.eaio.uuid.UUID;
import com.project.dao.message.AttachmentDao;
import com.project.dao.message.MessageDao;
import com.project.dao.message.WorkScoreDao;
import com.project.dao.organization.EmployeeDao;
import com.project.entity.message.Attachment;
import com.project.entity.message.MessageWork;
import com.project.entity.message.WorkScore;
import com.project.entity.organization.Department;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by samsung on 2018/5/3.
 */
@Controller
@RequestMapping("/fileupload")
public class FileUploadController {

    // 上传文件存储目录
    private static final String UPLOAD_DIRECTORY = "E://upload//header//result";
    private static final String UPLOAD_HEADdIRECTORY = "E:\\upload\\header";

    // 上传配置
    private static final int MEMORY_THRESHOLD = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE = 1024 * 1024 * 40; // 40MB
    private static final int MAX_REQUEST_SIZE = 1024 * 1024 * 50; // 50MB

    /*注入的服务*/
    @Autowired
    private EmployeeDao employeeDao;

    @Autowired
    private AttachmentDao attachmentDao;

    @Autowired
    private WorkScoreDao workScoreDao;

    @Autowired
    private MessageDao messageDao;

    /*作业提交*/
    @RequestMapping("/workUploadForStu")
    @ResponseBody
    public String workUploadForStu(HttpServletRequest request, HttpServletResponse response) throws IOException {

        // 检测是否为多媒体上传
        if (!ServletFileUpload.isMultipartContent(request)) {
            // 如果不是则停止
            PrintWriter writer = response.getWriter();
            writer.println("Error: 表单必须包含 enctype=multipart/form-data");
            writer.flush();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message","上传失败");
            jsonObject.put("status",false);
            return jsonObject.toJSONString();
        }

        // 配置上传参数
        DiskFileItemFactory factory = new DiskFileItemFactory();
        // 设置内存临界值 - 超过后将产生临时文件并存储于临时目录中
        factory.setSizeThreshold(MEMORY_THRESHOLD);

        // 设置临时存储目录
        factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

        ServletFileUpload upload = new ServletFileUpload(factory);

        // 设置最大文件上传值
        upload.setFileSizeMax(MAX_FILE_SIZE);

        // 设置最大请求值 (包含文件和表单数据)
        upload.setSizeMax(MAX_REQUEST_SIZE);

        // 中文处理
        upload.setHeaderEncoding("UTF-8");

        // 构造临时路径来存储上传的文件
        // 这个路径相对当前应用的目录

        HttpSession httpSession = request.getSession();
        Operator operator = (Operator) httpSession.getAttribute("operator");
        Employee employee = operator.getEmployee();
        Department department = employee.getDepartment();
        String deptCode = department.getCode();
        String orgName = department.getOrgName();
        String type = "student";

        Map<String,String> params = new HashMap<String, String>();
        try {
            // 解析请求的内容提取文件数据

            //学生提交的记录
            WorkScore workScore = new WorkScore();
            workScore.setSubmiter(operator.getId());
            workScore.setCreateDate(new Date());
            String attachementGroupId = new UUID().toString();
            workScore.setAttachementCode(attachementGroupId);
            MessageWork messageWork = null;
            List<FileItem> formItems = upload.parseRequest(request);
            if (formItems != null && formItems.size() > 0) {
                // 迭代表单数据
                for (FileItem item : formItems) {
                    // 处理不在表单中的字段
                    if (!item.isFormField()) {
                        int messageId = Integer.parseInt(String.valueOf(params.get("messageId")));

                        //查询出一条记录
                        JSONObject obj = new JSONObject();
                        obj.put("messageId",messageId);
                        messageWork = messageDao.findMessageWorkById(obj);
                        String resultPath = messageWork.getResultPath();
                        if(messageWork == null){
                            JSONObject error = new JSONObject();
                            error.put("status",false);
                            error.put("message","查找作业失败");
                            error.put("code",405);
                            return error.toJSONString();
                        }

                        /*提交的每一个文件应该由姓名_学号_文件名称构建而成*/
                        String empName = operator.getEmployee().getName() != null?operator.getEmployee().getName():operator.getUsername();
                        String fileName = empName  + "_"+ operator.getUsername() + "_" + item.getName();
                        // 如果目录不存在则创建

                        //创建目录baseURl + type + messageId + filename
                        String path = resultPath + File.separator + messageId + File.separator;
                        String fileDist = resultPath + File.separator + messageId +File.separator+ fileName;
                        File uploadDir = new File(UPLOAD_DIRECTORY + path);
                        if (!uploadDir.exists()) {
                            uploadDir.mkdirs();
                        }

                        workScore.setWorkMessageId(messageId);
                        //保存附件记录
                        Attachment attachment = new Attachment();
                        UUID uuidO = new UUID();
                        attachment.setAttachmentId(uuidO.toString());
                        attachment.setAttachmentName(fileName);
                        attachment.setCreateDate(new Date());
                        attachment.setPath(path);
                        attachment.setAttachmentGroupId(attachementGroupId);
                        attachmentDao.insertAttachment(attachment);
                        //保存学生提交的记录
                        workScoreDao.insertScore(workScore);

                        File storeFile = new File(UPLOAD_DIRECTORY + fileDist);
                        // 在控制台输出文件的上传路径
                        System.out.println(fileDist);
                        // 保存文件到硬盘
                        item.write(storeFile);
                        request.setAttribute("message",
                                "文件上传成功!");
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("message","上传成功");
                        jsonObject.put("status",true);
                        jsonObject.put("data",messageId);
                        return jsonObject.toJSONString();
                    }else{
                        params.put(item.getFieldName(),item.getString());
                    }
                }
            }
        } catch (Exception ex) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("message","上传失败");
            jsonObject.put("status",false);
            request.setAttribute("message",
                    "错误信息: " + ex.getMessage());
            ex.printStackTrace();
            return jsonObject.toJSONString();
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("message","上传失败");
        jsonObject.put("status",false);
        return jsonObject.toJSONString();
    }

    @RequestMapping("/uploadHeader")
    @ResponseBody
    public String uploadHeader(HttpServletRequest request){
        try {
            // 配置上传参数
            DiskFileItemFactory factory = new DiskFileItemFactory();
            // 设置内存临界值 - 超过后将产生临时文件并存储于临时目录中
            factory.setSizeThreshold(MEMORY_THRESHOLD);

            // 设置临时存储目录
            factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

            ServletFileUpload upload = new ServletFileUpload(factory);

            // 设置最大文件上传值
            upload.setFileSizeMax(MAX_FILE_SIZE);

            // 设置最大请求值 (包含文件和表单数据)
            upload.setSizeMax(MAX_REQUEST_SIZE);

            // 中文处理
            upload.setHeaderEncoding("UTF-8");

            HttpSession httpSession = request.getSession();
            Operator operator = (Operator) httpSession.getAttribute("operator");
            Employee employee = operator.getEmployee();

            String uploadPath = UPLOAD_HEADdIRECTORY + "//" + employee.getId() + "//";

            // 如果目录不存在则创建
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            try {
                // 解析请求的内容提取文件数据
                List<FileItem> formItems = upload.parseRequest(request);

                if (formItems != null && formItems.size() > 0) {
                    // 迭代表单数据
                    for (FileItem item : formItems) {
                        // 处理不在表单中的字段
                        if (!item.isFormField()) {
                            String fileName = new File(item.getName()).getName();
                            String filePath = uploadPath + File.separator + fileName;
                            File storeFile = new File(filePath);
                            // 在控制台输出文件的上传路径
                            System.out.println(filePath);
                            // 保存文件到硬盘
                            item.write(storeFile);
                            request.setAttribute("message",
                                    "文件上传成功!");
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("message","上传成功");
                            jsonObject.put("imgName",fileName);
                            jsonObject.put("status",true);
                            Employee saved = employeeDao.findAnEmployeeByEmail(employee.getEmail());
                            saved.setAliasName(fileName);
                            Employee updated = employeeDao.updateEmployee(saved);

                            return jsonObject.toJSONString();
                        }
                    }
                }else{
                    return "";
                }
            } catch (Exception ex) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("message","上传失败");
                jsonObject.put("status",false);
                request.setAttribute("message",
                        "错误信息: " + ex.getMessage());
                return jsonObject.toJSONString();
            }
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
        return "";
    }
}
