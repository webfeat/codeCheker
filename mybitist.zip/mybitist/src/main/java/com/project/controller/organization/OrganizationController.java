package com.project.controller.organization;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/org")
public class OrganizationController {

    /**
     * 查找单位
     **/
    @ResponseBody
    @RequestMapping("/getOrganizationById")
    public String getOrganizationById(HttpServletRequest request){
        return "";
    }

}
