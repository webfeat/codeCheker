package com.project.controller.organization;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.organization.EmployeeDao;
import com.project.dao.organization.organizationImp.EmployeeDaoBean;
import com.project.entity.organization.Employee;
import com.project.entity.permission.Operator;
import com.project.service.organization.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/employeeController")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @Autowired
    EmployeeDao employeeDao;

    @RequestMapping(value = "/getEmployee",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public  String getEmployee(String id,HttpServletRequest request){
        String idStr = request.getParameter("id");
        JSONObject jsonObject = new JSONObject();
        Integer employeeIdInteger = Integer.parseInt(idStr);

        try{
            EmployeeDaoBean employeeDao = new EmployeeDaoBean();
            Employee employee = employeeDao.getEmployeeById(employeeIdInteger);

            jsonObject.put("data",employee);
            jsonObject.put("state",200);
            jsonObject.put("message","成功");

            String result = jsonObject.toJSONString();

            return result;
        }catch (Exception e){

            jsonObject.put("data",null);
            jsonObject.put("message","失败");
            jsonObject.put("state","500");

            e.printStackTrace();
        }
        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/updateEmployee",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public  String updateEmployee(HttpServletRequest request){
        String employeeName = request.getParameter("employeeName");
        String employeeId = request.getParameter("employeeId");
        String schoolName = request.getParameter("schoolName");
        Operator operator = (Operator)request.getSession().getAttribute("operator");
        if(operator == null){
            JSONObject error = new JSONObject();
            error.put("code",503);
            error.put("status",false);
            error.put("message","未登录");
            return error.toJSONString();
        }
        JSONObject jsonObject = new JSONObject();

        try{

            Employee employee = employeeDao.getEmployeeById(Integer.parseInt(employeeId));
            employee.setSchoolName(schoolName);
            employee.setName(employeeName);

            Employee saved = employeeDao.updateEmployee(employee);
            jsonObject.put("data",employee);
            jsonObject.put("state",200);
            jsonObject.put("message","成功");

            String result = jsonObject.toJSONString();

            return result;
        }catch (Exception e){

            jsonObject.put("data",null);
            jsonObject.put("message","失败");
            jsonObject.put("state","500");

            e.printStackTrace();
        }
        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/findEmployeeLIst",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findEmployeeLIst(HttpServletRequest request){
        String departmentId = request.getParameter("departmentId");
        int deptId = Integer.parseInt(departmentId);

        JSONObject params = new JSONObject();
        params.put("departmentId",deptId);
        List<Employee> list = employeeDao.selectAllEmployeeByDept(params);

        JSONObject result = new JSONObject();
        result.put("data",list);
        result.put("status",true);
        result.put("message","查询成功");
        return result.toJSONString();
    }

}
