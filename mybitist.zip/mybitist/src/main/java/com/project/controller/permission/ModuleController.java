package com.project.controller.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.permission.ModuleDao;
import com.project.entity.permission.Module;
import com.project.entity.permission.Operator;
import com.project.service.permission.ModuleService;
import com.project.util.RequestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/module")
public class ModuleController {

    @Autowired
    RequestUtil requestUtil;

    @Autowired
    ModuleService moduleService;

    @Resource
    ModuleDao moduleDao;

    @RequestMapping(value = "/insertAModule",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String insertAModule(HttpServletRequest request){
        JSONObject params = requestUtil.getParamsFromRequirest(request);
        JSONObject result = moduleService.saveModule(params);
        return result.toJSONString();
    }

    @RequestMapping(value = "/updateAModule",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String updateAModule(HttpServletRequest request){
        JSONObject params = requestUtil.getParamsFromRequirest(request);
        Module module = new Module();
        module.setIcon(params.getString("Icon"));
        module.setIsSystemModule(params.getString("isSystemModule"));
        module.setIsUsed(params.getString("isUsed"));
        module.setModuleCode(params.getString("moduleCode"));
        module.setModuleName(params.getString("moduleName"));
        module.setModuleRoute(params.getString("moduleRoute"));
        module.setId(params.getInteger("id"));
        if(params.getInteger("parentModuleId") != null){
            module.setParentModuleId(params.getInteger("parentModuleId"));
        }

        int count = moduleDao.updateAModule(module);
        if(count == 0){
            JSONObject error = new JSONObject();
            error.put("status",false);
            error.put("message","更新失败");
            return error.toJSONString();
        }else{
            JSONObject message = new JSONObject();
            message.put("status",true);
            message.put("message","更新成功");
            return message.toJSONString();
        }
    }


    /*左边菜单*/
    @RequestMapping(value="/findModuleList",method = RequestMethod.GET,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findModuleList(HttpServletRequest request){
        String parentModuleId = request.getParameter("parentModuleId");
        Operator operator = (Operator)request.getSession().getAttribute("operator");
        if(operator == null){
            JSONObject error = new JSONObject();
            error.put("code",503);
            error.put("status",true);
            error.put("message","失败");
            return error.toJSONString();
        }
        JSONObject result = moduleService.findModulesByParentModuleId(parentModuleId,operator.getId());
        return result.toJSONString();
    }

    @RequestMapping(value="/findModuleListGrid",method = RequestMethod.GET,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findModuleListGrid(HttpServletRequest request){
        String currentPage = request.getParameter("currentPage");
        String pageNo = request.getParameter("pageNo");
        JSONObject paramsJson = new JSONObject();
        paramsJson.put("currentPage",(Integer.parseInt(currentPage) - 1) * Integer.parseInt(pageNo));
        paramsJson.put("pageNo",Integer.parseInt(pageNo));

        List<Module> list = moduleDao.findModuleList(paramsJson);
        JSONObject jsonObject = new JSONObject();

        List<Module> allList = moduleDao.findModuleList(new JSONObject());
        jsonObject.put("pageSize",Math.ceil(allList.size()/Integer.valueOf(String.valueOf(paramsJson.get("pageNo")))));
        jsonObject.put("totalItems",allList.size());
        jsonObject.put("status",200);
        jsonObject.put("data",list);
        jsonObject.put("message","成功");
        return jsonObject.toJSONString();
    }

    /*查询某一个模块*/
    @RequestMapping(value="/findAModule",method = RequestMethod.GET,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findAModule(HttpServletRequest request ){
        JSONObject params = requestUtil.getParamsFromRequirest(request);

       Module module = moduleDao.findModuleById(String.valueOf(params.get("moduleId")));

       JSONObject result = new JSONObject();
       result.put("status",true);
       result.put("data",module);
       result.put("message","查找完成");
       return result.toJSONString();
    }

    /*删除某一个模块*/
    @RequestMapping(value="/deleteAModule",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String deleteAModule(HttpServletRequest request ){
        JSONObject params = requestUtil.getParamsFromRequirest(request);

        Module module = moduleDao.findModuleById(String.valueOf(params.get("moduleId")));
        int count = moduleDao.deleteAModule(module);
        JSONObject result = new JSONObject();
        if(count >0){
            result.put("status",true);
        }else{
            result.put("status",false);
        }
        result.put("message","删除完成");
        return result.toJSONString();
    }

}
