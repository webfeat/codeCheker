package com.project.controller.permission;

import com.alibaba.fastjson.JSONObject;
import com.project.entity.permission.Role;
import com.project.service.permission.RoleService;
import com.project.util.RequestUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/role")
public class RoleController {


    @Autowired
    RoleService roleService;

    @Autowired
    RequestUtil requestUtil;

    //查找角色列表
    @RequestMapping(value = "/findRoleList",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findRoleList(HttpServletRequest request){
        JSONObject jsonObject = new JSONObject();
        String currentPage = request.getParameter("currentPage");
        String pageNo = request.getParameter("pageNo");

        jsonObject.put("currentPage",Integer.valueOf(currentPage) - 1);
        jsonObject.put("pageNo",Integer.valueOf(pageNo));

        JSONObject result = new JSONObject();
        result = roleService.findRoleList(jsonObject);
        return result.toJSONString();
    }

    //插入一条角色新数据
    @RequestMapping(value = "/updateRole",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String updateRole(HttpServletRequest request){

        String code = request.getParameter("code");
        String name = request.getParameter("name");
        String roleId = request.getParameter("roleId");

        Role role = new Role();
        role.setCode(code);
        role.setName(name);
        role.setId(Integer.parseInt(roleId));
        role.setUpdateDate(new Date());

        JSONObject jsonObject = roleService.updateRole(role);

        return jsonObject.toJSONString();
    }

    //插入一条角色新数据
    @RequestMapping(value = "/InsertNewRole",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String InsertNewRole(HttpServletRequest request){

        String code = request.getParameter("code");
        String name = request.getParameter("name");

        Role role = new Role();
        role.setCode(code);
        role.setName(name);
        role.setCreateDate(new Date());

        JSONObject jsonObject = roleService.insertRole(role);

        return jsonObject.toJSONString();
    }

    @RequestMapping(value = "/deleteRoleById",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String deleteRoleById(HttpServletRequest request){
        String roleId = request.getParameter("roleId");
        Role role = roleService.findRoleById(roleId);
        JSONObject jsonObject = roleService.deleteById(role);
        return jsonObject.toJSONString();
    }


    @RequestMapping(value = "/findRoleById",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String findRoleById(HttpServletRequest request){
        String roleId = request.getParameter("roleId");
        Role role = roleService.findRoleById(roleId);
        JSONObject jsonObject = new JSONObject();

        jsonObject.put("status",true);
        jsonObject.put("data",role);
        jsonObject.put("code",200);

        return jsonObject.toJSONString();
    }



}
