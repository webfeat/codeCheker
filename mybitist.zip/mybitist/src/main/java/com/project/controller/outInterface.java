package com.project.controller;

import com.alibaba.fastjson.JSONObject;
import com.project.service.organization.EmployeeService;
import com.project.util.RequestUtil;
import com.project.util.SchoolCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by samsung on 2018/3/18.
 */

@Controller
@RequestMapping("/outInface")
public class outInterface {

    @Autowired
    RequestUtil requestUtil;

    @Autowired
    EmployeeService employeeService;

    //通过院校名称关键字查询到学校，
    @RequestMapping(value = "/getBillCodeByName",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String getBillCodeByName(HttpServletRequest request) throws Exception{
        String schoolName = request.getParameter("schoolName");
        request.setCharacterEncoding("utf-8");
        SchoolCode schoolCode = new SchoolCode();
        Map<String,String> result = schoolCode.getSchoolCodeByName(schoolName);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data",result);
        jsonObject.put("status",200);
        jsonObject.put("message","成功");
        return jsonObject.toJSONString();
    }

//    /*统计最近三次作业提交率*/
//    @RequestMapping(value = "/countSubmitForL",produces = "text/html;charset=UTF-8")
//    @ResponseBody
//    public void countSubmitForL(HttpServletRequest request){
//        employeeService
//    }

}
