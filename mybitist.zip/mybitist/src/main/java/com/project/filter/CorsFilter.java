package com.project.filter;
import com.thetransactioncompany.cors.CORSFilter;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

public class CorsFilter extends OncePerRequestFilter {

    public CorsFilter() {
        System.err.println("==== 初始化系统允许跨域请求 ====");
    }



    /**
     * 解决跨域：Access-Control-Allow-Origin，值为*表示服务器端允许任意Domain访问请求
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        HttpSession session = request.getSession();
        System.out.println("跨域处理:" + session.getId());
        String url = request.getRequestURL().toString();
        System.out.println(url);
        Map map = request.getParameterMap();
//        filterChain.doFilter(request, response);
        super.doFilter(request,response,filterChain);
    }

    public void destroy() {
    }
}
