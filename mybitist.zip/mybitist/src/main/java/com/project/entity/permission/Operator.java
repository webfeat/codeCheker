package com.project.entity.permission;

import com.project.entity.Entity;
import com.project.entity.organization.Employee;

public class Operator extends Entity{
    private String username;//用户名
    private String password;//登陆密码
    private Employee employee;//与employee 为一对一的关系
    private int empId;//与employee 为一对一的关系
    private String operatorId;//操作员Id
    private String attachementCode;//附件code
    private String appId;//appId，做页面消息推送时（发送私人消息），做的id
    private String attachmentId;

    public String getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    public int getEmpId() {
        return empId;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }

    public String getAttachementCode() {
        return attachementCode;
    }

    public void setAttachementCode(String attachementCode) {
        this.attachementCode = attachementCode;
    }
}
