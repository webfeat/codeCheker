package com.project.entity;

import com.project.entity.permission.Operator;

public class OperatorConfig extends Entity{
    private Operator operator;//每一个人对应一个配置

    /**
     * 消息推送配置
     */

    private boolean memeberChange;//班级成员变动消息推送
    private boolean homeworkEnd;//作业到期
    private boolean personMessage;//个人消息
    private boolean pulishedHomeWork;//发布消息的通知
    private boolean pulishedMaterial;//发布资料的通知
    private String menberGroup;//每个人对自己的好友都有一个或多个分组，采用json存储
    private String messageConfig;
    private String groupConfig;
    private int operatorId;
    private int departmentId;

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public int getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(int operatorId) {
        this.operatorId = operatorId;
    }

    public String getGroupConfig() {
        return groupConfig;
    }

    public void setGroupConfig(String groupConfig) {
        this.groupConfig = groupConfig;
    }

    public String getMessageConfig() {
        return messageConfig;
    }

    public void setMessageConfig(String messageConfig) {
        this.messageConfig = messageConfig;
    }

    public boolean isPulishedHomeWork() {
        return pulishedHomeWork;
    }

    public void setPulishedHomeWork(boolean pulishedHomeWork) {
        this.pulishedHomeWork = pulishedHomeWork;
    }

    public boolean isPulishedMaterial() {
        return pulishedMaterial;
    }

    public void setPulishedMaterial(boolean pulishedMaterial) {
        this.pulishedMaterial = pulishedMaterial;
    }

    public String getMenberGroup() {
        return menberGroup;
    }

    public void setMenberGroup(String menberGroup) {
        this.menberGroup = menberGroup;
    }

    public Operator getOperator() {
        return operator;
    }

    public void setOperator(Operator operator) {
        this.operator = operator;
    }

    public boolean isMemeberChange() {
        return memeberChange;
    }

    public void setMemeberChange(boolean memeberChange) {
        this.memeberChange = memeberChange;
    }

    public boolean isHomeworkEnd() {
        return homeworkEnd;
    }

    public void setHomeworkEnd(boolean homeworkEnd) {
        this.homeworkEnd = homeworkEnd;
    }

    public boolean isPersonMessage() {
        return personMessage;
    }

    public void setPersonMessage(boolean personMessage) {
        this.personMessage = personMessage;
    }

}
