package com.project.entity;

import java.util.Date;

/**
 * Created by samsung on 2018/6/4.
 */
public class MessageView {
    private int id;
    private Date createDate;
    private String setSubject;
    private String message;
    private int departmentId;
    private int creatorId;
    private String type;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getSetSubject() {
        return setSubject;
    }

    public void setSetSubject(String setSubject) {
        this.setSubject = setSubject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public int getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(int creatorId) {
        this.creatorId = creatorId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
