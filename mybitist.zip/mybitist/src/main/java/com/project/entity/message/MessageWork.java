package com.project.entity.message;

import com.project.entity.Entity;

import java.util.Date;
import java.util.List;

/**
 * Created by samsung on 2018/5/16.
 */
public class MessageWork extends Entity{
    private String titile;
    private String content;
    private String type;
    private String status;
    private int creatorId;
    private String uploadPath;
    private String resultPath;
    private Date endTime;
    private int departmentId;
    private List<Attachment> attachmentList;
    private List<WorkScore> workScores;

    public List<WorkScore> getWorkScores() {
        return workScores;
    }

    public void setWorkScores(List<WorkScore> workScores) {
        this.workScores = workScores;
    }

    public List<Attachment> getAttachmentList() {
        return attachmentList;
    }

    public void setAttachmentList(List<Attachment> attachmentList) {
        this.attachmentList = attachmentList;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public String getTitile() {
        return titile;
    }

    public void setTitile(String titile) {
        this.titile = titile;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(int creatorId) {
        this.creatorId = creatorId;
    }

    public String getUploadPath() {
        return uploadPath;
    }

    public void setUploadPath(String uploadPath) {
        this.uploadPath = uploadPath;
    }

    public String getResultPath() {
        return resultPath;
    }

    public void setResultPath(String resultPath) {
        this.resultPath = resultPath;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}
