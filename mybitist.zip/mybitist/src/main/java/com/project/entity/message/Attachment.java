package com.project.entity.message;

import com.project.entity.Entity;


public class Attachment extends Entity{
    private String attachmentName;
    private String attachmentId;//附件ID
    private String attachmentGroupId;//多附件ID
    private String attachmentType;//附件类型
    private String path;//附件存储路径

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getAttachmentName() {
        return attachmentName;
    }

    public void setAttachmentName(String attachmentName) {
        this.attachmentName = attachmentName;
    }

    public String getAttachmentId() {
        return attachmentId;
    }

    public void setAttachmentId(String attachmentId) {
        this.attachmentId = attachmentId;
    }

    public String getAttachmentGroupId() {
        return attachmentGroupId;
    }

    public void setAttachmentGroupId(String attachmentGroupId) {
        this.attachmentGroupId = attachmentGroupId;
    }

    public String getAttachmentType() {
        return attachmentType;
    }

    public void setAttachmentType(String attachmentType) {
        this.attachmentType = attachmentType;
    }
}
