package com.project.entity.organization;

import com.project.entity.Entity;

import java.util.List;

public class Organization extends Entity{

    private List<Department> departments;//单位下的部门
    private String organizationName;//单位名称
    private String organizationCode;//单位编码
    private String iconUrl;//单位Logo
    private String orgPhoneNum;

    public String getOrgPhoneNum() {
        return orgPhoneNum;
    }

    public void setOrgPhoneNum(String orgPhoneNum) {
        this.orgPhoneNum = orgPhoneNum;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public List<Department> getDepartments() {
        return departments;
    }

    public void setDepartments(List<Department> departments) {
        this.departments = departments;
    }
}
