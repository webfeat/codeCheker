package com.project.entity.organization;

/**
 * 好友关系中间表
 */
public class EmployeeAndEmp {
    private Employee employeeA;//成员A
    private Employee employeeB;//成员B
    private String relationShip;//关系名称

    public Employee getEmployeeA() {
        return employeeA;
    }

    public void setEmployeeA(Employee employeeA) {
        this.employeeA = employeeA;
    }

    public Employee getEmployeeB() {
        return employeeB;
    }

    public void setEmployeeB(Employee employeeB) {
        this.employeeB = employeeB;
    }

    public String getRelationShip() {
        return relationShip;
    }

    public void setRelationShip(String relationShip) {
        this.relationShip = relationShip;
    }
}
