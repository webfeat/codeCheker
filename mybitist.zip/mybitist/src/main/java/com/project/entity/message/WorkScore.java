package com.project.entity.message;

import com.project.entity.Entity;

public class WorkScore extends Entity {
    private int submiter;
    private int workMessageId;
    private int status;
    private int score;
    private int comment;

    public int getSubmiter() {
        return submiter;
    }

    public void setSubmiter(int submiter) {
        this.submiter = submiter;
    }

    public int getWorkMessageId() {
        return workMessageId;
    }

    public void setWorkMessageId(int workMessageId) {
        this.workMessageId = workMessageId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getComment() {
        return comment;
    }

    public void setComment(int comment) {
        this.comment = comment;
    }
}
