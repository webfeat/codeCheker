package com.project.entity.message;

import com.project.entity.Entity;
import com.project.entity.organization.Department;
import com.project.entity.permission.Operator;

import java.util.Date;

public class PersonMessage extends Entity {
    /**
     *
     */
    private String title;//消息标题
    private String content;//消息文本内容
    private String from;
    private String to ;//json字符串，存储的要发送的人员
    private String attachmentCode;//附件消息
    private Operator sendOperator;//发送人员
    private int sendOperatorId;
    private Date endTime;//作业截止日期
    private int deptId;//属于哪个班级的消息
    private Department department;//获取班级
    private String uploadPath;
    private String resultPath;

    public String getUploadPath() {
        return uploadPath;
    }

    public void setUploadPath(String uploadPath) {
        this.uploadPath = uploadPath;
    }

    public String getResultPath() {
        return resultPath;
    }

    public void setResultPath(String resultPath) {
        this.resultPath = resultPath;
    }

    public Operator getSendOperator() {
        return sendOperator;
    }

    public void setSendOperator(Operator sendOperator) {
        this.sendOperator = sendOperator;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getAttachmentCode() {
        return attachmentCode;
    }

    public void setAttachmentCode(String attachmentCode) {
        this.attachmentCode = attachmentCode;
    }

    public int getSendOperatorId() {
        return sendOperatorId;
    }

    public void setSendOperatorId(int sendOperatorId) {
        this.sendOperatorId = sendOperatorId;
    }
}
