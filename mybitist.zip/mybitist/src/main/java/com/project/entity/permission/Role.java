package com.project.entity.permission;

import com.project.entity.Entity;

public class Role extends Entity{
    private String name;//角色名称
    private String code;//角色编码
    private int roleGrade;//设置用户级别，分别到达某个级别时，强制安排一些权限，默认100，权重越大，权限越大

    public int getRoleGrade() {
        return roleGrade;
    }

    public void setRoleGrade(int roleGrade) {
        this.roleGrade = roleGrade;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public void setCode(String code) {
        this.code = code;
    }
}
