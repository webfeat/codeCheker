package com.project.entity.organization;

import com.project.entity.Entity;

public class Department extends Entity {
    private Organization orgId;//所属单位
    private int orgpId;//
    private String orgName;//所属院校
    private String deptName;//部门名称
    private String deptCode;//部门编码
    private String depPhoneNum;
    private String type;
    private String applyCode;
    private String principalId;//部门负责人ID
    private Employee  principal;//部门负责人
    private int employeeId;

    public int getOrgpId() {
        return orgpId;
    }

    public void setOrgpId(int orgpId) {
        this.orgpId = orgpId;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public Employee getPrincipal() {
        return principal;
    }

    public void setPrincipal(Employee principal) {
        this.principal = principal;
    }

    public String getPrincipalId() {
        return principalId;
    }

    public void setPrincipalId(String principalId) {
        this.principalId = principalId;
    }

    public String getDepPhoneNum() {
        return depPhoneNum;
    }

    public void setDepPhoneNum(String depPhoneNum) {
        this.depPhoneNum = depPhoneNum;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getApplyCode() {
        return applyCode;
    }

    public void setApplyCode(String applyCode) {
        this.applyCode = applyCode;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Organization getOrgId() {
        return orgId;
    }

    public void setOrgId(Organization orgId) {
        this.orgId = orgId;
    }
}
