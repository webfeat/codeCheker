package com.project.entity;

import java.util.Date;

public class Entity {

    public Entity(){
        this.createDate = new Date();
    }

    public Date createDate;//创建时间

    public Date updateDate;//更新时间

    public int id;//主键，id

    public String code;//编码

    public String attachementCode;//附件编码

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAttachementCode() {
        return attachementCode;
    }

    public void setAttachementCode(String attachementCode) {
        this.attachementCode = attachementCode;
    }
}
