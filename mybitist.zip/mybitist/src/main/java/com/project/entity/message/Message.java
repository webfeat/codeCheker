package com.project.entity.message;

import com.project.entity.Entity;

import java.util.List;

public class Message extends Entity{
    private String authCode;//验证码
    private String setSubject;//主题
    private String email;//邮箱
    private String message;//发送的消息
    private String type;//也是用途：表示注册、找回密码、等等
    private int departmentId;
    private List<Attachment> attachmentList;
    private List<WorkScore> workScores;
    private int creatorId;

    public int getCreatorId() {
        return creatorId;
    }

    public void setCreatorId(int creatorId) {
        this.creatorId = creatorId;
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(int departmentId) {
        this.departmentId = departmentId;
    }

    public List<WorkScore> getWorkScores() {
        return workScores;
    }

    public void setWorkScores(List<WorkScore> workScores) {
        this.workScores = workScores;
    }

    public List<Attachment> getAttachmentList() {
        return attachmentList;
    }

    public void setAttachmentList(List<Attachment> attachmentList) {
        this.attachmentList = attachmentList;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getSetSubject() {
        return setSubject;
    }

    public void setSetSubject(String setSubject) {
        this.setSubject = setSubject;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
