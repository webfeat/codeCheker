package com.project.entity.permission;

import com.project.entity.Entity;

public class Permission extends Entity{
    private String name;//权限点名称
    private String code;//权限点编码

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public void setCode(String code) {
        this.code = code;
    }
}
