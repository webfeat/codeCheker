package com.project.entity.permission;

import com.project.entity.Entity;
import com.sun.org.apache.xpath.internal.operations.Mod;

import java.util.List;

public class Module extends Entity{
    private String moduleName;//模块名称
    private String moduleCode;//模块编码
    private Module subModuleId;//子模块
    private String hasParentModule;//是否有父模块
    private Module parentModule;//父模块ID
    private List<Module> subModules;
    private int parentModuleId;
    private String ModuleRoute;//模块路由
    private String isUsed;//是否启用
    private String isSystemModule;//是否是系统模块
    private String icon;

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public List<Module> getSubModules() {
        return subModules;
    }

    public void setSubModules(List<Module> subModules) {
        this.subModules = subModules;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getModuleCode() {
        return moduleCode;
    }

    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }

    public Module getSubModuleId() {
        return subModuleId;
    }

    public void setSubModuleId(Module subModuleId) {
        this.subModuleId = subModuleId;
    }

    public String getHasParentModule() {
        return hasParentModule;
    }

    public void setHasParentModule(String hasParentModule) {
        this.hasParentModule = hasParentModule;
    }

    public Module getParentModule() {
        return parentModule;
    }

    public void setParentModule(Module parentModule) {
        this.parentModule = parentModule;
    }

    public int getParentModuleId() {
        return parentModuleId;
    }

    public void setParentModuleId(int parentModuleId) {
        this.parentModuleId = parentModuleId;
    }

    public String getModuleRoute() {
        return ModuleRoute;
    }

    public void setModuleRoute(String moduleRoute) {
        ModuleRoute = moduleRoute;
    }

    public String getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(String isUsed) {
        this.isUsed = isUsed;
    }

    public String getIsSystemModule() {
        return isSystemModule;
    }

    public void setIsSystemModule(String isSystemModule) {
        this.isSystemModule = isSystemModule;
    }
}
