package com.project.util;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.pusher.rest.Pusher;
import com.pusher.rest.data.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * pusher，消息推送，推送参数为对象，这里我们采用json对象
 */
@Repository
public class PusherUtil {


    @Autowired
    PropertiesUtil propertiesUtil = new PropertiesUtil();

    /**
     *params:uuid为operator表中的appId,每个人都是不一样的，postMessagae为对象，推送的消息为这个，此功能仅作用于个人消息发送
     * 群通知消息：在前端放置两个接收器，uuid也可以是班级uuid，（欠缺的考虑，未发送的怎么保存）
     */

    public void pushMessageToClient(String uuid, JSONObject postMessage) throws  Exception{
        JSONObject appObject = new JSONObject();
        appObject = propertiesUtil.getPusherMessage();

        String appId = (String) appObject.get("app_id");
        String key = (String) appObject.get("key");
        String secret = (String) appObject.get("secret");
        String cluster = (String) appObject.get("cluster");

        Pusher pusher = new Pusher(appId, key, secret);
        pusher.setCluster(cluster);
        pusher.setEncrypted(true);

        //uuid为操作员的唯一码
        Result result = pusher.trigger("my-channel", uuid, postMessage);
        int statushttp = result.getHttpStatus();
        String message = result.getMessage();
        Result.Status status = result.getStatus();

    }


    public static void main(String[] args){
        PusherUtil pusherUtil = new PusherUtil();

        JSONObject jsObject = new JSONObject();
        jsObject.put("1","这是我的消息");
        jsObject.put("2","这是你的消息");
        jsObject.put("3","这是他的消息");
        jsObject.put("4","这是她的消息");

        try {
            pusherUtil.pushMessageToClient("吴玉明",jsObject);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
