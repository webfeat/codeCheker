package com.project.util;

import com.project.entity.message.Message;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Repository;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.util.Date;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

@Repository
public class AuthenUtil {

    private static String KEY_ALGORITHM = "AES";
    private static String CIPHER_ALGORITHM_ECB = "AES/ECB/PKCS5Padding";
    private static SecretKey secretKey;
    private static Cipher cipher;

    public AuthenUtil() {
        try {
            if(secretKey == null){
                secretKey = KeyGenerator.getInstance(KEY_ALGORITHM).generateKey();
            }
            if(cipher == null){
                cipher = Cipher.getInstance(CIPHER_ALGORITHM_ECB);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 生成验证码
     */
    public String generateAuthCode(String email,String m_text,String subject,String type){
        //生成验证码
        String virifiedCode = generateCode();
        Message message = new Message();
        message.setAuthCode(virifiedCode);
        message.setEmail(email);
        message.setMessage(m_text);
        message.setSetSubject(subject);
        message.setType(type);
        message.setCreateDate(new Date());

        //存储到数据库

        //发送邮件
        return "";
    }

    public boolean checkAuthCode(){
        //从数据库中查询

        //校验，验证码是否过期

        // 取最新的一条验证码，验证是否正确
        return true;
    }

    public String generateCode(){
        double number = Math.random()*1000000;
        return String.valueOf(number).substring(0,5);
    }

    //解密
    public String decodeAes(String encrypt){
        try {
            byte[] decrypt = new byte[16];
            String[] str = encrypt.split(",");

            for(int i = 0 ; i < str.length ;i++){
                decrypt[i] = Byte.parseByte(str[i]);
            }

            cipher.init(Cipher.DECRYPT_MODE, secretKey);//使用解密模式初始化 密钥

            byte[] t = cipher.doFinal(decrypt);
            return new String(t);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    //解密算法
    //aes加密
    public String encodeAes(String password){
        try {
            //KeyGenerator 生成aes算法密钥
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);//使用加密模式初始化 密钥
            byte[] encrypt = cipher.doFinal(password.getBytes()); //按单部分操作加密或解密数据，或者结束一个多部分操作。
            String str = "";
            for(int i = 0 ; i < encrypt.length ; i++){
                if(i == encrypt.length - 1){
                    str += String.valueOf(encrypt[i]) ;
                }else{
                    str += String.valueOf(encrypt[i]) + ',';
                }
            }

            return str;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }



    //token生成工具
    private static Logger log = Logger.getLogger(AuthenUtil.class.toString());
    private static Key getKeyInstance(){
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary("APP");
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
        return signingKey;
    }

    public static String createJavaWebToken(Map<String, Object> claims) {
        return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS256, getKeyInstance()).compact();
    }

    public static Map<String, Object> verifyJavaWebToken(String jwt) {
        try {

            Map<String, Object> jwtClaims = Jwts.parser().setSigningKey(getKeyInstance()).parseClaimsJws(jwt).getBody();
            return jwtClaims;
        } catch (Exception e) {
            log.log(Level.ALL,"异常",new Throwable("token生成异常"));
            return null;
        }
    }


    //
    //生成随机数字和字母,
    public static String getStringRandom(int length) {

        String val = "";
        Random random = new Random();

        //参数length，表示生成几位随机数
        for(int i = 0; i < length; i++) {

            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            //输出字母还是数字
            if( "char".equalsIgnoreCase(charOrNum) ) {
                //输出是大写字母还是小写字母
                int temp = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char)(random.nextInt(26) + temp);
            } else if( "num".equalsIgnoreCase(charOrNum) ) {
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }

}
