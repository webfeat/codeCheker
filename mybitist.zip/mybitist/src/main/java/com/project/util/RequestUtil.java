package com.project.util;

import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Repository;

import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

@Repository
public class RequestUtil {
    /**
     * 从请求对象中获取得到参数
     *
     * @return jsonObject
     */
    public JSONObject getParamsFromRequirest(HttpServletRequest request){
        Map<String,String > map = request.getParameterMap();
        Set<String> keyset = map.keySet();
        Iterator<String> iter = keyset.iterator();

        JSONObject parmas = new JSONObject();
        while (iter.hasNext()){
            String temp = iter.next();
            parmas.put(temp,request.getParameter(temp));
        }

        return parmas;
    }
}
