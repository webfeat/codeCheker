package com.project.util;

import jplag.JPlag;
import org.springframework.stereotype.Repository;

/**
 * Created by samsung on 2018/5/26.
 */
@Repository
public class JPlagApi {

    //-l java17 -s D:\test -vlpd -r D:\test

    private static String optionLanguage = "-l";
    private static String languege = "java17";
    private static String optionSource = "-s";//扫描目录
    private static String optionDir = "-r";//生成结果的目录
    private static String outputlevel = "-vlpd";//输出级别
    private static String[] args = new String[7];

    static {
        args[0] = optionLanguage;
        args[1] = languege;
        args[2] = optionSource;
        args[4] = outputlevel;
        args[5] = optionDir;
    }

    public void run(String distPath,String resourcePath){
        args[3] = resourcePath;
        args[6] = distPath;
        JPlag jPlag = new JPlag();
        jPlag.run(args);
    }

}
