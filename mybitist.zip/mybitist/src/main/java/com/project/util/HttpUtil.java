package com.project.util;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Created by samsung on 2018/3/18.
 */
public class HttpUtil {

    public static String generateParamStr(Map<String, String> params) {
        if (params != null && !params.isEmpty()) {
            // 提前定义的集合类，用于数据处理
            Set<String> keySet = params.keySet();
            Iterator<String> keyIterator = keySet.iterator();
            ArrayList<String> queryList = new ArrayList<String>();

            // 循环遍历，存储请求条件
            while (keyIterator.hasNext()) {
                String tempKey = keyIterator.next();
                String value = params.get(tempKey);
                String tempQuey = tempKey + "=" + value;
                queryList.add(tempQuey);
            }

            String queryStr = "";
            // 从存储的条件中开始构建整个查询条件
            for (int i = 0; i < queryList.size(); i++) {
                if (i == queryList.size() - 1) {
                    queryStr += queryList.get(i);
                } else {
                    queryStr += queryList.get(i) + "&";
                }
            }
            return queryStr;
        }
        return "";
    }

    public static String post(String urL, Map<String, String> params)
            throws IOException {
        try {
            URL url = new URL(urL);
            URLConnection connection = url.openConnection();
            connection.setDoOutput(true);
            OutputStreamWriter out = new OutputStreamWriter(
                    connection.getOutputStream(), "gbk");

            String queryStr = generateParamStr(params);
            System.out.println(queryStr);
            out.write(queryStr);
            // remember to clean up
            out.flush();
            out.close();

            // 一旦发送成功，用以下方法就可以得到服务器的回应：
            String sCurrentLine;
            String sTotalString;
            sCurrentLine = "";
            sTotalString = "";
            InputStream l_urlStream;
            l_urlStream = connection.getInputStream();

            BufferedReader l_reader = new BufferedReader(new InputStreamReader(
                    l_urlStream, "gbk"));
            while ((sCurrentLine = l_reader.readLine()) != null) {
                sTotalString += sCurrentLine + "\r\n";
            }
            return sTotalString;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return "";
    }
}
