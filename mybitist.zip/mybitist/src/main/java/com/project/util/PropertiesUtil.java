package com.project.util;

import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Repository;

import java.util.Properties;
import java.util.ResourceBundle;

@Repository
public class PropertiesUtil {
    /**
     *
     * @return
     * @throws Exception
     */
    public JSONObject getPusherMessage() throws Exception{
        JSONObject jsonObject = new JSONObject();

        Properties properties = new Properties();
        ResourceBundle resource = ResourceBundle.getBundle("app.properties");
        String app_id = resource.getString("app_id");
        String key = resource.getString("key");
        String secret = resource.getString("secret");
        String cluster = resource.getString("cluster");

        jsonObject.put("app_id",app_id);
        jsonObject.put("key",key);
        jsonObject.put("secret",secret);
        jsonObject.put("cluster",cluster);

        return jsonObject;
    }
}
