package com.project.util;

import com.project.entity.organization.Employee;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public class PathGenerator {
    /**
     * 每次作业的上传地址，主要目的是为了方便每次作业的解析
     * @params:schoolCode+teacherCode+classCode+workPublishDate+uploadPath为上传路径
     * @params:schoolCode+teacherCode+classCode+workPublishDate+resultPath为解析结果存放路径
     */
    public String generateRecoverDealPath(Employee employee, Date workPublishDate,String schoolCode){
        String path = schoolCode + employee.getCode() + employee.getDepartment().getDeptCode() + workPublishDate.toString();
        return path;
    }
}
