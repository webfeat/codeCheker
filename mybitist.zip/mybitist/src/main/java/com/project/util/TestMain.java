package com.project.util;

import com.alibaba.fastjson.JSONObject;
import com.project.dao.permission.permissionImp.OperaotrConfigDaoBean;
import com.project.entity.OperatorConfig;
import com.project.entity.message.Message;
import jplag.JPlag;

import javax.annotation.Resource;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.lang.Byte;
import java.lang.String;
import java.util.Map;

@Resource
public class TestMain {


    private String KEY_ALGORITHM = "AES";
    private String CIPHER_ALGORITHM_ECB = "AES/ECB/PKCS5Padding";
    private  SecretKey secretKey;
    private Cipher cipher;

    public void timeTest() throws Exception{
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm");

        String fromDate = simpleDateFormat.format("2016-05-01 12:00");
        String toDate = simpleDateFormat.format("2016-05-01 12:50");
        long from = simpleDateFormat.parse(fromDate).getTime();
        long to = simpleDateFormat.parse(toDate).getTime();
        int minutes = (int) ((to - from)/(1000 * 60));
        System.out.println("from ("+ from + ") - to("+ to +") = " + minutes);
    }

    static byte[] getIV() {
        String iv = "1234567812345678"; //IV length: must be 16 bytes long
        return iv.getBytes();
    }

    public static void main(String[] args) throws  Exception{
//        TestMain testMain = new TestMain();
//        String str = testMain.encodeAes("123456");
//        String test = testMain.decodeAes(str);
//        System.out.println(test);
//        SchoolCode schoolCode = new SchoolCode();
//        Map<String,String> map = schoolCode.getSchoolCodeByName("重庆");

//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put("message",true);
//        jsonObject.put("empChange",true);
//        jsonObject.put("workEnd",true);
//        jsonObject.put("workBublish",true);
//        String messageConfig = jsonObject.toJSONString();
//
//
//        OperatorConfig operatorConfig = new OperatorConfig();
//        operatorConfig.setMessageConfig(messageConfig);
//        operatorConfig.setCreateDate(new Date());
//        operatorConfig.setOperatorId(1);
//
//        OperaotrConfigDaoBean o = new OperaotrConfigDaoBean();
//        o.insertOperatorConfig(operatorConfig);

//        EmailUtil emailUtil = new EmailUtil();
//        emailUtil.sendEmail("",new Message(),"12121");
        String params = "-l java17 -s D:\\test -vlpd -r D:\\test";
        String[] paramArr = params.split(" ");
        JPlag d = new JPlag();
        d.run(paramArr);

    }

    //aes加密
    public String encodeAes(String password){
        try {
            cipher = Cipher.getInstance(CIPHER_ALGORITHM_ECB);
            //KeyGenerator 生成aes算法密钥
            secretKey = KeyGenerator.getInstance(KEY_ALGORITHM).generateKey();
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);//使用加密模式初始化 密钥
            byte[] encrypt = cipher.doFinal(password.getBytes()); //按单部分操作加密或解密数据，或者结束一个多部分操作。
            String str = "";
            for(int i = 0 ; i < encrypt.length ; i++){
                if(i == encrypt.length - 1){
                    str += String.valueOf(encrypt[i]) ;
                }else{
                    str += String.valueOf(encrypt[i]) + ',';
                }
            }

            return str;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public String decodeAes(String encrypt){
        try {
            byte[] decrypt = new byte[16];
            String[] str = encrypt.split(",");

            for(int i = 0 ; i < str.length ;i++){
                decrypt[i] = Byte.parseByte(str[i]);
            }

            cipher.init(Cipher.DECRYPT_MODE, secretKey);//使用解密模式初始化 密钥

            byte[] t = cipher.doFinal(decrypt);
            return new String(t);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
