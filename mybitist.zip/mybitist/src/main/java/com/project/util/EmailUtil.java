package com.project.util;

import com.project.entity.message.Message;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

@Repository
public class EmailUtil {

    @Autowired
    AuthenUtil authenUtil;

    /*发送验证码*/
    public boolean sendEmail(String toAddress, Message message,String text){
        Email email = new SimpleEmail();
        email.setHostName("smtp.163.com");
        email.setSmtpPort(465);
        email.setAuthenticator(new DefaultAuthenticator("18306032164@163.com", "wym147852"));
        email.setSSLOnConnect(true);

        String varifiedCode = message.getAuthCode();

        try{
            email.setFrom("18306032164@163.com","天天科技","utf-8");
            email.setSubject(message.getSetSubject());
            email.setMsg(text + varifiedCode);
            String[] emials = toAddress.split(",");
            email.addTo(emials);
            email.send();
            return true;
        }catch (EmailException e){
            e.printStackTrace();
            return false;
        }
    }

    /*多人发送邮件*/
    public boolean sendMessageEmail(String toAddress,String subject,String text ){
        Email email = new SimpleEmail();
        email.setHostName("smtp.163.com");
        email.setSmtpPort(465);
        email.setAuthenticator(new DefaultAuthenticator("18306032164@163.com", "wym147852"));
        email.setSSLOnConnect(true);

        try{
            email.setFrom("18306032164@163.com","天天科技","utf-8");
            email.setSubject(subject);
            email.setMsg(text);
            String[] emials = toAddress.split(",");
            email.addTo(emials);
            email.send();
            return true;
        }catch (EmailException e){
            e.printStackTrace();
            return false;
        }
    }

    /*将字符串格式化为时间格式*/
    public static Date dateFormateToDate(String strDate){
        String date = strDate;
        date = date.replace("Z", " UTC");//注意是空格+UTC
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS Z");//注意格式化的表达式
        try {
            Date d = format.parse(date );
            return d;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
