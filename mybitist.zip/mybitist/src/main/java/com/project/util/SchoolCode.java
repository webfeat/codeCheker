package com.project.util;

import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Created by samsung on 2018/3/18.
 */
public class SchoolCode {

    /**
     * 分析dom结构
     * @return
     */

    public Map<String,String> getResult(String html){

        //将html转换为文档结构
        Document doc = (Document) Jsoup.parse(html);
        Elements trs = doc.select("table");
        Iterator<Element> iterator = trs.iterator();
        ArrayList<Element> elements = new ArrayList<Element>();
        //第一阶段获取所有的table
        while (iterator.hasNext()) {
            Element element = iterator.next();
            elements.add(element);
        }

        //第二阶段获取到最后一个table
        Element lastTable = elements.get(elements.size() -1);

        //此处的tr包括表头的tr,所以先删除第一个
        Elements ttrs = lastTable.select("tr");
        ttrs.remove(0);
        ttrs.remove(0);

        /**
         * dataElements:用于存储数据tr
         */
        Iterator<Element> trIterator = ttrs.iterator();
        ArrayList<Element> dataElements = new ArrayList<Element>();
        //第二阶段获取所有的具有数据的tr
        while (trIterator.hasNext()) {
            Element element = trIterator.next();
            dataElements.add(element);
        }


        //定义map存储学校代号与学校名称
        Map<String, String> map = new HashMap<String, String>();
        for(int i = 0 ; i < dataElements.size() ; i++){

            Element trElement = dataElements.get(i);
            Elements tempTdElements = trElement.select("td");
            Iterator<Element> tdIterator = tempTdElements.iterator();

            while(tdIterator.hasNext()){
                String key = "",value = "";
                Element codeElement = tdIterator.next();
                if(codeElement.hasText()){//如果有文本
                    key = codeElement.text();
                }

                Element nameElement = tdIterator.next();
                if(nameElement.hasText()){//如果有文本
                    value = nameElement.text();
                }
                map.put(key, value);
            }
        }
        return map;
    }


    public Map<String,String> getSchoolCodeByName(String key){
        Map<String, String> map = new HashMap<String, String>();
        Map<String, String> resultMap = new HashMap<String, String>();

        map.put("qtype", "1");
        map.put("para", key);


        try {
            //发出请求
            String result = HttpUtil.post("http://pub.sinoss.net/portal/webgate/CmdSearchUniv", map);

            //解析文档结构获取数据集
            resultMap = getResult(result);
            //打印结果
            Set<String> resultSet = resultMap.keySet();
            Iterator<String> keyIterator = resultSet.iterator();
            while (keyIterator.hasNext()) {
                String tempKey = keyIterator.next();
                System.out.println(tempKey + resultMap.get(tempKey));
            }
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
        return resultMap;
    }

}
