package com.project.util;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.stereotype.Repository;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;

@Repository
public class SqlFactoryUtil {

    /**
     * 采用单例子模式
     */
    public static String resource = "mybatis-config.xml";

    public SqlSession sqlSession;


    public SqlSession openSession() throws Exception{
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);

        sqlSession = sqlSessionFactory.openSession();
        sqlSession.clearCache();

        return sqlSession;
    }

    public void commitSession(){
        sqlSession.commit();
    }

    public void rollback(){
        sqlSession.rollback();
    }

    private static final SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmssSSS");
    private static String preId = "";

    public static synchronized String createId(){
        String id = format.format(Calendar.getInstance().getTime());
        while(id.equals(preId)){
            id = format.format(Calendar.getInstance().getTime());
        }
        preId = id;
        return id;
    }
}
